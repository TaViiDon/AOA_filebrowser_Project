package com.java.azure;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.blob.models.BlobProperties;




public class AzureBlobWindow extends JFrame{
	
	private static final long serialVersionUID = 1L;
	private final NavigationStack navigationStack;
    private final JTextArea fileMetadataArea;
    private JList<File> fileList;
    private final DefaultListModel<File> fileListModel;
    private final JButton backButton;
    private final JButton forwardButton;
    private final JTextField searchField;
    private final BlobContainerClient containerClient;
    private AzureBlobStorage azureBlobStorage;
    private JList<String> folderList;
    private DefaultListModel<String> folderListModel;
    private JScrollPane rightScrollPane;
    private JScrollPane leftScrollPane;
	private JPanel fileListPanel;
	private JPanel fileMetadataPanel; 
	private String folderNameSelected;
	private List<String> files;//Stores a list of files in the container
    private List<String> folders;//Stores a list of folders in the container
	
	    // Constructor to initialize Azure Blob connection and GUI components
	    public AzureBlobWindow(String connectionString, String containerName) {
	    	
	    	
	    	// Set up Azure Blob Storage
	        BlobServiceClient serviceClient = new BlobServiceClientBuilder().connectionString(connectionString).buildClient();
	        containerClient = serviceClient.getBlobContainerClient(containerName);
	    	
	    	 navigationStack = new NavigationStack();
	         setTitle("File Explorer");
	         setSize(800, 600);
	         setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	         setLayout(new BorderLayout());
	       //setupMainFrame();
	        

	         
	         // Initialize components
	         backButton = new JButton("Back <--- ");
	         forwardButton = new JButton("Forward ---> ");
	         fileMetadataArea = new JTextArea();
	         fileListModel = new DefaultListModel<>();
	         fileList = new JList<>(fileListModel);
	         fileList.setLayoutOrientation(JList.VERTICAL);
	         azureBlobStorage = new AzureBlobStorage(connectionString,containerName);
	         folderNameSelected = containerName;

	         folders = new ArrayList<>();
	         files = new ArrayList<>();
	         
	         searchField = new JTextField(20);
	         searchField.addActionListener(e -> {
	             String query = searchField.getText(); // Get the text from the search field
	           //  String resultMessage = searchFiles(query); // Call the searchFiles method with the query

	             // Display the result message to the user
	            // JOptionPane.showMessageDialog(this, resultMessage, "Search Result", JOptionPane.INFORMATION_MESSAGE);
	         });
	         
	         


	         // Disable buttons initially
	         backButton.setEnabled(false);
	         forwardButton.setEnabled(false);

	         // Layout setup
	         JPanel navigationPanel = new JPanel();
	         navigationPanel.add(backButton);
	         navigationPanel.add(forwardButton);
	         navigationPanel.add(searchField);
	         
	      // Assuming splitPane is already created as in your code
	         leftScrollPane = new JScrollPane(fileList); // Get the left (first) component
	         //fileListPanel = (JPanel) leftScrollPane.getViewport().getView(); // Get the panel inside the scroll pane
	         
	         rightScrollPane = new JScrollPane(fileMetadataArea); // Get the left (first) component
	         //fileMetadataPanel = (JPanel) leftScrollPane.getViewport().getView(); // Get the panel inside the scroll pane
	         
	         JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftScrollPane,rightScrollPane );
	         splitPane.setDividerLocation(300);

	         add(navigationPanel, BorderLayout.NORTH);
	         add(splitPane, BorderLayout.CENTER);
	         
	         
	         // Right-click popup menu for creating a folder
	         //JPopupMenu popupMenu = new JPopupMenu();
	         //JMenuItem createFolderItem = new JMenuItem("Create Folder");
	         //popupMenu.add(createFolderItem);
	        // createFolderItem.addActionListener(e -> createFolder());
	         
	         
	         /* Action listeners
	          backButton.addActionListener((ActionEvent e) -> {
	             goBack();
	         });

	         forwardButton.addActionListener((ActionEvent e) -> {
	             goForward();
	         });*/

	       
	         
	         
	         // Add mouse listener for right-click popup on fileList
	         fileList.addMouseListener(new MouseAdapter() {
	             @Override
	             public void mousePressed(MouseEvent e) {
	                 if (SwingUtilities.isRightMouseButton(e)) {
	                	//popupMenu.show(e.getComponent(), e.getX(), e.getY());	
	                	 showContextMenu(e,folderNameSelected);
	                	
	                 }
	             }
	         });
	         
	         fileList.addMouseListener(new MouseAdapter() {
	        	    @Override
	        	    public void mouseClicked(MouseEvent e) {
	        	        if (SwingUtilities.isLeftMouseButton(e)) {
	        	            // Get the index of the clicked item
	        	            int index = fileList.locationToIndex(e.getPoint());

	        	            // Check if the index is valid (non-negative) and get the selected item
	        	            if (index >= 0) {
	        	                Object selectedItem = fileList.getModel().getElementAt(index);
	        	                folderNameSelected=selectedItem.toString();
	        	            }
	        	        }
	        	    }
	        	});
	         
	         //Double-click listener on the file list to open folders or preview files
	         
	         fileList.addMouseListener(new MouseAdapter() {
	             @Override
	             public void mouseClicked(MouseEvent e) {
	                 if (e.getClickCount() == 2) {
	                     File selectedFile = fileList.getSelectedValue();
	                     if (selectedFile != null) {
	                    	 
	                    	 /*for(String folderName:files) {
	                    		 System.out.println(folderName);
	                    	 }*/
	                    	 
	                    	 
	                         if (folders.contains(selectedFile.toString()+"/")) {//selectedFile.isDirectory()
	                            // navigateTo(selectedFile);
	                        	System.out.println(selectedFile.toString());
	                         } 
	                         else {
	                        	 //TODO: Update this method to handle files
	                        	 //selectedFile = fileList.getE
	                             displayFilePreview(selectedFile);
	                         }
	                     }
	                 }
	             }
	         });
	         

	         refreshFileExplorer();
	         setVisible(true);
	         
	         
	     }
	    
	    private void showContextMenu(MouseEvent e, String folderName) {
	    	//folderNameSelected=folderName;
	    	//System.out.println(folderNameSelected);
	        // Create popup menu
	        JPopupMenu contextMenu = new JPopupMenu();

	        // "Create Folder" menu item
	        JMenuItem createFolderItem = new JMenuItem("Create Folder");
	        createFolderItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent event) {
	            	createFolder();  // Call create folder method
	            }
	        });
	        contextMenu.add(createFolderItem);

	        // "Upload File" menu item
	        JMenuItem uploadFileItem = new JMenuItem("Upload File");
	        uploadFileItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent event) {
	                uploadFileToFolder(folderName);  // Call upload file method
	            }
	        });
	        contextMenu.add(uploadFileItem);

	        // "Download Folder/File" menu item
	        JMenuItem downloadItem = new JMenuItem("Download Folder/File");
	        downloadItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent event) {
	                downloadFolderOrFile(folderName);  // Call download method
	            }
	        });
	        contextMenu.add(downloadItem);

	        // Show popup menu at the mouse click location
	        contextMenu.show(e.getComponent(), e.getX(), e.getY());
	    }
	    
	    
	    
	 // Method to update the file list
	    public void updateFileList(List<String> files) {
	        fileListPanel.removeAll(); // Clear current list of files

	        // Add each file as a label or component to the panel
	        for (String fileName : files) {
	            JLabel fileLabel = new JLabel(fileName);
	            fileListPanel.add(fileLabel);
	        }

	        // Refresh the panel to display new content
	        fileListPanel.revalidate();
	        fileListPanel.repaint();
	    }
	    
	    private void loadFolders() {
	        // Clear the current list
	        folderListModel.clear();

	        // Fetch folders from Azure Blob Storage
	        folders = azureBlobStorage.getFolders();

	        // Add each folder to the GUI list model
	        for (String folder : folders) {
	            folderListModel.addElement(folder);
	        }
	    }
	    
	    
	    public void refreshFileExplorer() {
	        fileListModel.clear(); // Clear existing items

	        // Fetch files and folders from Azure Blob Storage
	        azureBlobStorage.getFilesAndDirectories();
	        
	        files = azureBlobStorage.getFiles();
	        folders = azureBlobStorage.getFolders();
	        
	        for (String fileName : files) {
	        	// Create a File object for each file name
	            File file = new File(fileName);
	            
	            // Optionally, you can write initial content to each file (example content here)
	            /*
	            try (FileWriter writer = new FileWriter(file)) {
	                writer.write("" + fileName);
	            } catch (IOException e) {
	                e.printStackTrace();
	            }*/
	            
	            // Add the File object to the model
	            fileListModel.addElement(file);
	        }
	        for (String folderName : folders) {
	        	// Create a File object for each file name
	            File file = new File(folderName);
	            
	            // Optionally, you can write initial content to each file (example content here)
	            /*
	            try (FileWriter writer = new FileWriter(file)) {
	                writer.write("" + fileName);
	            } catch (IOException e) {
	                e.printStackTrace();
	            }*/
	            
	            // Add the File object to the model
	            fileListModel.addElement(file);
	        }
	        
	        //updateFileList(filesAndDirs);
	    }
	    
	      // Method to create a new folder
	         private void createFolder() {
	             String folderName = JOptionPane.showInputDialog(this, "Enter Folder Name:", "Create Folder", JOptionPane.PLAIN_MESSAGE);

	             if (folderName != null && !folderName.trim().isEmpty()) {
	                 // Add a "/" to the end of folder name to signify it's a folder
	                 String blobFolderName = folderName + "/";

	                 // Create a blob client for the folder
	                 BlobClient blobClient = containerClient.getBlobClient(blobFolderName);

	                 // Upload empty content to create the "folder"
	                 blobClient.upload(new ByteArrayInputStream(new byte[0]), 0);
	                 refreshFileExplorer();

	                 JOptionPane.showMessageDialog(this, "Folder created: " + folderName, "Folder Creation", JOptionPane.INFORMATION_MESSAGE);
	             } else {
	                 JOptionPane.showMessageDialog(this, "Folder name cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
	             }
	         

	         // Additional helper methods (e.g., for file metadata, file preview) would go here.
	     }
	         
	      // Method to upload a file to the specified folder
	         private void uploadFileToFolder(String folderName) {
	             JFileChooser fileChooser = new JFileChooser();
	             int option = fileChooser.showOpenDialog(this);
	             if (option == JFileChooser.APPROVE_OPTION) {
	                 File file = fileChooser.getSelectedFile();
	                 if (file != null) {
	                     AzureBlobStorage azureBlobStorage = this.azureBlobStorage;
	                     azureBlobStorage.uploadFile(folderName, file);
	                     JOptionPane.showMessageDialog(this, "File uploaded successfully!");
	                 }
	             }
	         }
	         
	      // Method to download a folder or file
	        /* private void downloadFolderOrFile(String folderName) {
	             AzureBlobStorage azureBlobStorage = this.azureBlobStorage;
	             azureBlobStorage.downloadFile(folderName);
	             JOptionPane.showMessageDialog(this, "Download started!");
	         }*/
	         
	         private void downloadFolderOrFile(String folderName) {
	        	    JFileChooser directoryChooser = new JFileChooser();
	        	    directoryChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	        	    int option = directoryChooser.showSaveDialog(this);

	        	    if (option == JFileChooser.APPROVE_OPTION) {
	        	        File localDirectory = directoryChooser.getSelectedFile();
	        	        String localDirectoryPath = localDirectory.getAbsolutePath();

	        	        // Download the selected file or folder to the specified local directory
	        	        azureBlobStorage.downloadFileOrFolder(folderName, localDirectoryPath);
	        	        JOptionPane.showMessageDialog(this, "Download completed!");
	        	    }
	        	}

	         
	         // Start browsing in the home directory
	        // navigateTo(new File(System.getProperty("user.home")));
	         
	         
	         
	     
	    
	    
	    
	    

	     /*
	     private void setupMainFrame() {
	         JFrame mainFrame = new JFrame("File Browser with Azure Blob Storage");
	         mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	         mainFrame.setSize(800, 600);
	         mainFrame.setLayout(new BorderLayout());

	         // Ensure getFileTreeComponent() method is available in AzureBlobWindow
	         mainFrame.add(azureBlobWindow.getFileTreeComponent(), BorderLayout.CENTER);

	         mainFrame.setVisible(true);
	     }*/
	 	// -------------------------------------------------------------------------
	     // simple search feature
	     // -------------------------------------------------------------------------
	    // private String searchFiles(String query){
	         // This should be able to search all the current folder we are at for a specific file
	         // file can be broken down into a few structures:
	         // - name, type, preview text, date created
	         // enter key to perform search

	         // Clear the current file list
	        // fileListModel.clear();
	         
	         // Get all files in the current directory
	        // File[] files = currentDirectory.listFiles();
	        // int matchCount = 0; // Counter for matching files

	         //if (files != null) {
	             //for (File file : files) {
	               //  boolean matches = false;

	                 // Check if the file name contains the search query
	                // if (file.getName().toLowerCase().contains(query.toLowerCase())) {
	                    // matches = true;
	                 //}

	                 // Check if the file type matches
	                 //String fileType = getFileType(file); 
	                // if (fileType.toLowerCase().contains(query.toLowerCase())) {
	                   //  matches = true;
	               //  }

	                

	                 // If it matches any criteria, add it to the list
	               //  if (matches) {
	                //     fileListModel.addElement(file);
	                 //    matchCount++; // Increment match count
	                // }
	           //  }
	       //  }

	         // Return a message based on the search results
	        // if (matchCount == 0) {
	          //   return "No files found matching \"" + query + "\".";
	       //  } else {
	           //  return matchCount + " file(s) found matching \"" + query + "\".";
	        // }
	   //  }

	   //  private void navigateTo(File directory) {
	    //     if (currentDirectory != null) {
	        //     navigationStack.pushBack(currentDirectory);
	       //  }
	       //  currentDirectory = directory;
	       //  updateFileList(directory);
	      //   updateNavigationButtons();
	  //   }

	   //  private void updateFileList(File directory) {
	    //     fileListModel.clear();
	     //    File[] files = directory.listFiles();
	      //   if (files != null) {
	      //       Arrays.sort(files);
	       //      for (File file : files) {
	        //         fileListModel.addElement(file);
	        //     }
	       //  }
	       //  displayFileMetadata(directory);
	   //  }

	     /*private void goBack() {
	         File previousDirectory = navigationStack.goBack(currentDirectory);
	         if (previousDirectory != null) {
	             currentDirectory = previousDirectory;
	             updateFileList(previousDirectory);
	        }
	         updateNavigationButtons();
	     }

	     private void goForward() {
	         File nextDirectory = navigationStack.goForward(currentDirectory);
	         if (nextDirectory != null) {
	             currentDirectory = nextDirectory;
	             updateFileList(nextDirectory);
	         }
	         updateNavigationButtons();
	     }

	     private void updateNavigationButtons() {
	         backButton.setEnabled(navigationStack.canGoBack());
	         forwardButton.setEnabled(navigationStack.canGoForward());
	     }*/
	    
	   

	     // -------------------------------------------------------------------------
	     // Creating a hash map to hold a few file types and their coresponding magic numbers
	     // -------------------------------------------------------------------------
	     private static final Map<String, String> MAGIC_NUMBERS = new HashMap<>();
	     static {
	         // some basic photo file types
	         MAGIC_NUMBERS.put("FFD8FF", "JPEG Image");
	         MAGIC_NUMBERS.put("89504E47", "PNG Image");
	         MAGIC_NUMBERS.put("47494638", "GIF Image");
	         MAGIC_NUMBERS.put("25504446", "PDF Document");
	         MAGIC_NUMBERS.put("424D", "BMP Image");
	         MAGIC_NUMBERS.put("49492A00", "TIFF Image (little-endian)");
	         MAGIC_NUMBERS.put("4D4D002A", "TIFF Image (big-endian)");
	   
	          // Audio and Video Types
	         MAGIC_NUMBERS.put("66747970", "MP4"); // MP4/MOV (ftyp)
	         MAGIC_NUMBERS.put("494433", "MP3"); // MP3 (ID3v2)
	         MAGIC_NUMBERS.put("FFFB", "MP3"); // MP3 (MPEG Header)
	         MAGIC_NUMBERS.put("FFF3", "MP3"); // MP3 (MPEG Header)
	         MAGIC_NUMBERS.put("52494646", "WAV"); // WAV/AVI (RIFF)
	         MAGIC_NUMBERS.put("41564920", "AVI"); // AVI
	         MAGIC_NUMBERS.put("664C6143", "FLAC"); // FLAC (fLaC)
	         MAGIC_NUMBERS.put("1A45DFA3", "MKV"); // MKV (EBML)
	         MAGIC_NUMBERS.put("494433", "MP3 Audio");
	         MAGIC_NUMBERS.put("52494646", "WAV Audio");

	         // Basic document types
	         //MAGIC_NUMBERS.put("D0CF11E0A1B11AE1", "DOC");
	         //MAGIC_NUMBERS.put("504B0304", "DOCX"); 
	         MAGIC_NUMBERS.put("D0CF11E0", "Microsoft Office (DOC, XLS, PPT)"); // Compound File Binary Format
	         MAGIC_NUMBERS.put("504B0304", "Microsoft Office/ZIP Archive (DOCX, XLSX, PPTX)"); // ZIP-based formats
	         MAGIC_NUMBERS.put("0x00000000", "Open Document Format (ODT, ODS, ODP)"); // ODF files (general case)
	     }

	     // -------------------------------------------------------------------------
	     // Creating a method that is able to detect the file type based on it's magic number
	     // -------------------------------------------------------------------------
	     private String getFileType(File file) {
	         // Return "Directory" if the file is actually a directory
	         if (file.isDirectory()) {
	             return "Directory";
	         }
	         //System.out.println("getFileType");
	         // Attempt to read the file's magic number
	         try (FileInputStream fis = new FileInputStream(file)) {
	        	 System.out.println("Try block");
	             byte[] bytes = new byte[4]; // Read the first 4 bytes (can adjust for different formats)
	             if (fis.read(bytes) != -1) {
	                 // Convert bytes to hex
	                 StringBuilder hex = new StringBuilder();
	                 for (byte b : bytes) {
	                     hex.append(String.format("%02X", b));
	                 }
	                 
	                 
	                 // Check if the file's magic number matches any known file types
	                 for (Map.Entry<String, String> entry : MAGIC_NUMBERS.entrySet()) {
	                	 System.out.println("Het2Str "+ hex.toString()+" "+entry.getKey());
	                	 
	                     if (hex.toString().startsWith(entry.getKey())) {
	                         return entry.getValue(); // Return the matched file type
	                     }
	                 }
	             }
	         } catch (IOException e) {
	             e.printStackTrace();
	         }

	         return "Unknown Type"; // Return this if no match was found
	     }

	     // -------------------------------------------------------------------------
	     // Display metadata such as name, size, type, and last modified date
	     // -------------------------------------------------------------------------
	     private void displayFileMetadata(File file) {
	         StringBuilder metadata = new StringBuilder();
	         metadata.append("Name: ").append(file.getName()).append("\n");
	         metadata.append("Size: ").append(file.length()).append(" bytes\n");
	         metadata.append("Type: ").append(getFileType(file)).append("\n");
	         metadata.append("Last Modified: ").append(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
	                 .format(file.lastModified())).append("\n");
	         fileMetadataArea.setText(metadata.toString());
	     }

	     // -------------------------------------------------------------------------
	     // Display file preview (for text files, show the first few lines)
	     // -------------------------------------------------------------------------
	     private void displayFilePreview(File file) {

	         if (file.isFile() && file.getName().endsWith(".txt")) {
	             try (FileReader fr = new FileReader(file); Scanner scanner = new Scanner(fr)) {
	                 StringBuilder preview = new StringBuilder();
	                 int lineCount = 0;
	                 while (scanner.hasNextLine() && lineCount < 10) {
	                     preview.append(scanner.nextLine()).append("\n");
	                     lineCount++;
	                 }
	                 fileMetadataArea.setText(preview.toString());
	                 
	             } catch (IOException ex) {
	                 fileMetadataArea.setText("Unable to preview file.");
	             }
	         } else {
	             fileMetadataArea.setText("No preview available for this file.");
	         }
	         displayFileMetadata(file);
	     } 
	     
	     
	 }