package com.java.azure;

import java.util.Stack;

public class FileBrowserNavigation {
    private Stack<String> backStack;
    private Stack<String> forwardStack;
    private String currentDirectory;

    // Constructor
    public FileBrowserNavigation(String initialDirectory) {
        this.backStack = new Stack<>();
        this.forwardStack = new Stack<>();
        this.currentDirectory = initialDirectory;
    }

    // Navigate to a new directory
    public void navigateTo(String directory) {
        if (currentDirectory != null) {
            backStack.push(currentDirectory);
        }
        currentDirectory = directory;
        forwardStack.clear(); // Clear forward history
        System.out.println("Navigated to: " + currentDirectory);
    }

    // Go back to the previous directory
    public String goBack() {
        if (backStack.isEmpty()) {
            System.out.println("No previous directory to go back to.");
            
        }
        forwardStack.push(currentDirectory);
        currentDirectory = backStack.pop();
        System.out.println("Went back to: " + currentDirectory);
        return currentDirectory;
    }

    // Go forward to the next directory
    public String goForward() {
        if (forwardStack.isEmpty()) {
            System.out.println("No next directory to go forward to.");
            
        }
        backStack.push(currentDirectory);
        currentDirectory = forwardStack.pop();
        System.out.println("Went forward to: " + currentDirectory);
        return currentDirectory;
    }

    // Get the current directory
    public String getCurrentDirectory() {
        return currentDirectory;
    }
    public boolean isStackNull() {
        return backStack == null || forwardStack == null;
    }
    public boolean isBackStackEmpty() {
        return backStack.isEmpty();
    }

    public boolean isForwardStackEmpty() {
        return forwardStack.isEmpty();
    }
}

