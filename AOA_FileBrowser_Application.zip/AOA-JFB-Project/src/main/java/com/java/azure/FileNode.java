/*Tavoy Gordon - 2102035
Angel Pinnock - 2203595
Ricou Eldemire - 2108884
Antonio Goldson - 2206840*/


package com.java.azure;

import java.io.File;

//FileNode class to wrap File object for tree node

public class FileNode {
	
 private final File file;

 public FileNode(File file) {
     this.file = file;
 }

 public File getFile() {
     return file;
 }

 @Override
 public String toString() {
     return file.getName().isEmpty() ? file.getAbsolutePath() : file.getName();
 }
}