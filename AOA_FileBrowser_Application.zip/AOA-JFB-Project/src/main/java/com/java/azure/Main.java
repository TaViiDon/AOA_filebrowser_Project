
/*Tavoy Gordon - 2102035
Angel Pinnock - 2203595
Ricou Eldemire - 2108884
Antonio Goldson - 2206840*/

package com.java.azure;

import java.io.IOException;

import javax.swing.SwingUtilities;




public class Main {
	public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
        	// Provide the connection string and container name
            String connectionString = "DefaultEndpointsProtocol=https;AccountName=utechstorageaccount;AccountKey=q11sBckvv/3RpkndOGuNoxqT1i0SKmIUqy3f0mmFAds1bUu2ZuZ9XuqI49nSwn4OU7/FrbMN1h5U+AStNd5fsA==;EndpointSuffix=core.windows.net";
            String containerName = "utechstoragecontainer";
            

       
            AzureBlobWindow filebrowser = new AzureBlobWindow(connectionString, containerName);
            //filebrowser.refreshFileExplorer();
                  filebrowser.setVisible(true);
                  
                  
        });
        
        
    }

}
        
        
        
        
        
        
       