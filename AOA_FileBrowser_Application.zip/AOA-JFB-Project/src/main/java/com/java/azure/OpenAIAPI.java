/*Tavoy Gordon - 2102035
Angel Pinnock - 2203595
Ricou Eldemire - 2108884
Antonio Goldson - 2206840*/


package com.java.azure;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;




public class OpenAIAPI {
	
	public static String chatGPT(String message) {
        String url = "https://api.openai.com/v1/chat/completions";
        String apiKey = "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"; // Replace with your actual API key
        String model = "gpt-4"; // You can change the model if needed
        System.out.println("openai call");
        try {
            // Ensure the message is properly escaped for JSON
            message = message.replace("\"", "\\\"");

            // Encode the message content to avoid hidden problematic characters
            message = URLEncoder.encode(message, "UTF-8");

            // Build the JSON body
            String body = "{\"model\": \"" + model + "\", \"messages\": [{\"role\": \"user\", \"content\": \"" + message + "\"}]}";

            // Print the body to debug the JSON format
            System.out.println("Request Body: " + body);

            // Create the HTTP POST request
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Authorization", "Bearer " + apiKey);
            con.setRequestProperty("Content-Type", "application/json");
            con.setRequestProperty("Content-Security-Policy", "block-none");

            con.setDoOutput(true);
            try (OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream())) {
                writer.write(body);
                writer.flush();
            }

            // Check the response code
            int responseCode = con.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                System.err.println("Error: HTTP " + responseCode);
                try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getErrorStream()))) {
                    StringBuilder errorResponse = new StringBuilder();
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        errorResponse.append(inputLine);
                    }
                    System.err.println("Error Response: " + errorResponse.toString());
                }
                return null;
            }

            // Get the response
            StringBuilder response = new StringBuilder();
            try (BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
            }

            // Extract the content from the response
            return extractContentFromResponse(response.toString());
        } catch (IOException e) {
            System.err.println("Error in communication with the API: " + e.getMessage());
            return null;
        }
    }

    public static String extractContentFromResponse(String response) {
        int startMarker = response.indexOf("content") + 11; // Marker for where the content starts.
        int endMarker = response.indexOf("\"", startMarker); // Marker for where the content ends.
        return response.substring(startMarker, endMarker); // Returns the substring containing only the response.
    }
    
    
    
}


   


	