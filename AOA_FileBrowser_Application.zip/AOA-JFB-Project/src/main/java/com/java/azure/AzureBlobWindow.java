/*Tavoy Gordon - 2102035
Angel Pinnock - 2203595
Ricou Eldemire - 2108884
Antonio Goldson - 2206840*/
package com.java.azure;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
//import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
//import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
//import java.util.stream.Collectors;
import java.util.Set;
import java.util.Stack;
import java.util.Comparator;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
//import javax.swing.JTree;
import javax.swing.SwingUtilities;
//import javax.swing.tree.DefaultMutableTreeNode;
//import javax.swing.tree.DefaultTreeModel;
//import javax.swing.tree.TreePath;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFShape;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFTextShape;
import org.apache.poi.sl.usermodel.Shape;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.azure.core.http.rest.PagedIterable;
import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
//import com.azure.storage.blob.models.BlobProperties;
import com.azure.storage.blob.models.BlobItem;
import com.azure.storage.blob.models.BlobProperties;
import com.azure.storage.blob.models.BlobRange;
import com.azure.storage.blob.specialized.BlobClientBase;
import java.io.*;





public class AzureBlobWindow extends JFrame{
	
	private static final long serialVersionUID = 1L;
	private final NavigationStack navigationStack;
    private final JTextArea fileMetadataArea;
    private JList<File> fileList;
    private final DefaultListModel<File> fileListModel;
    private final JButton backButton;
    private final JButton forwardButton;
    private final JButton searchButton;
    private final JTextField searchField;
    private final BlobContainerClient containerClient;
	private BlobServiceClient blobServiceClient;
    private AzureBlobStorage azureBlobStorage;
    private JList<String> folderList;
    private DefaultListModel<String> folderListModel;
    private JScrollPane rightScrollPane;
    private JScrollPane leftScrollPane;
	private JPanel fileListPanel;
	private JPanel fileMetadataPanel; 
	private String folderNameSelected;
	private List<String> files;//Stores a list of files in the container
    private Set<String>  folders;//Stores a list of folders in the container
    private FolderCheckAndCreate folderChecker;
    private long sizeLimit = 10000000L; //1 GB //10000000L7 = 10 MB Size limit for the folder. 9
    private String localPath = "/Users/tavoygordon/temp"; 
    private String folderPath = "/Users/tavoygordon/temp"; 
    private String currentDirectory;
    String storageAccountUrl;
    String containerNameFixed;
    private Stack<String> forwardStack;// Stack to track forward navigation 
    public FileBrowserNavigation stackNav;
    public String currentFile;
    private boolean verbose = false;
    private boolean debugger = false;

    
    
	    
    
	    // Constructor to initialize Azure Blob connection and GUI components
	    public AzureBlobWindow(String connectionString, String containerName) {
	    	
	    	
	    	// Set up Azure Blob Storage
	        BlobServiceClient serviceClient = new BlobServiceClientBuilder().connectionString(connectionString).buildClient();
	        containerClient = serviceClient.getBlobContainerClient(containerName);
	    	  
	    	 navigationStack = new NavigationStack();
	    	 forwardStack = new Stack<>();
	    	 
	         setTitle("File Explorer 📂");
	         setSize(800, 600);
	         setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	         setLayout(new BorderLayout());
	       //setupMainFrame();
	        
	       
	         currentDirectory = "";
	         
	         // Initialize components
	         JPanel searchPanel = new JPanel();
	         backButton = new JButton(" <--- ");
	         forwardButton = new JButton(" ---> ");
	         fileMetadataArea = new JTextArea();
	         fileListModel = new DefaultListModel<>();
	         fileList = new JList<>(fileListModel);
	         fileList.setLayoutOrientation(JList.VERTICAL);
	         azureBlobStorage = new AzureBlobStorage(connectionString,containerName);
	         folderNameSelected = containerName;

	         folders = new HashSet<>();
	         files = new ArrayList<>();
	         
	         FolderCheckAndCreate folderChecker = new FolderCheckAndCreate();
	         
	        //jPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
	      // Create the search button (icon 🔎) and search field
	         searchButton = new JButton("🔎"); // Button for search icon
	         searchButton.setFocusable(true); // Optional: Remove focusable outline for aesthetics
	         searchButton.setEnabled(true);
	         searchField = new JTextField(20); // Text field for user input
	         
	         

	         // Add functionality to searchButton
	         searchButton.addActionListener(e -> {
	             // Perform search when the button is clicked
	             searchFileFolder(searchField.getText());
	         });

	         // Add functionality to searchField (pressing "Enter" triggers search)
	         searchField.addActionListener(e -> {
	             searchFileFolder(searchField.getText());
	         });

	         // Add components to the search panel in the correct order
	         searchPanel.add(searchButton); // Add the button first (left side)
	         searchPanel.add(searchField); // Add the text field next (right side)

	         // Add the search panel to the main frame
	         add(searchPanel, BorderLayout.NORTH);

	        
	         /*searchField.addActionListener(e -> {
	        	 //pass string entered by user to the searchFileFolder method
	             searchFileFolder(searchField.getText());
	             
	         });*/
	       
	         // Disable buttons initially
	         backButton.setEnabled(true);
	         //forwardButton.setEnabled(true);

	         // Layout setup
	         JPanel navigationPanel = new JPanel();
	         navigationPanel.add(backButton);
	         navigationPanel.add(forwardButton);
	         navigationPanel.add(searchButton);
	         navigationPanel.add(searchField);
	         
	      // Assuming splitPane is already created as in your code
	         leftScrollPane = new JScrollPane(fileList); // Get the left (first) component
	         //fileListPanel = (JPanel) leftScrollPane.getViewport().getView(); // Get the panel inside the scroll pane
	         
	         rightScrollPane = new JScrollPane(fileMetadataArea); // Get the left (first) component
	         //fileMetadataPanel = (JPanel) leftScrollPane.getViewport().getView(); // Get the panel inside the scroll pane
	         
	         JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftScrollPane,rightScrollPane );
	         splitPane.setDividerLocation(300);

	         add(navigationPanel, BorderLayout.NORTH);
	         add(splitPane, BorderLayout.CENTER);
	         
	         String storageAccountUrl = "https://utechstorageaccount.blob.core.windows.net/";
	         String containerNameFixed = "utechstoragecontainer";
	         
	         // Right-click popup menu for creating a folder
	         //JPopupMenu popupMenu = new JPopupMenu();
	         //JMenuItem createFolderItem = new JMenuItem("Create Folder");
	         //popupMenu.add(createFolderItem);
	        // createFolderItem.addActionListener(e -> createFolder());
	         
	         
	      // Back Button Action Listener
	          backButton.addActionListener((ActionEvent e) -> {
	        	
	        	  try {

		        	  //method to go back to the previous page
		        	  stackNav.goBack();
	        		    if (stackNav.isBackStackEmpty() || stackNav.isStackNull()) {
	        		        refreshFileExplorer();
	        		    } else {
	        		        try {
	        		            // Attempt to navigate back and list folder contents
	        		            navigateTo(stackNav.getCurrentDirectory());
	        		            listFolderContents(stackNav.getCurrentDirectory());
	        		        } catch (NullPointerException ex) {
	        		            System.err.println("Error: Null value encountered while navigating back.");
	        		            refreshFileExplorer();
	        		        } catch (Exception ex) {
	        		            System.err.println("An unexpected error occurred: " + ex.getMessage());
	        		            refreshFileExplorer();
	        		        }
	        		    }
	        		} catch (Exception ex) {
	        		    System.err.println("Error in navigation logic: " + ex.getMessage());
	        		    refreshFileExplorer();
	        		}
            	 System.out.println("Current Directory: " + stackNav.getCurrentDirectory());
            	 //System.out.println("Double click IF IF " + selectedFile.toString());
	         });

	          forwardButton.addActionListener((ActionEvent e) -> {
		        	 //check if stack is empty/null
		        	 try {
		        		    if (stackNav.isForwardStackEmpty() || stackNav.isStackNull()) {
		        		        refreshFileExplorer();
		        		    } else {
		        		        try {
		        		            // Attempt to navigate forward
		        		            navigateTo(stackNav.goForward());
		        		            listFolderContents(stackNav.getCurrentDirectory());
		        		        } catch (NullPointerException ex) {
		        		            System.err.println("Error: Null value encountered while navigating forward.");
		        		            refreshFileExplorer();
		        		        } catch (Exception ex) {
		        		            System.err.println("An unexpected error occurred: " + ex.getMessage());
		        		            refreshFileExplorer();
		        		        }
		        		    }
		        		} catch (Exception ex) {
		        		    System.err.println("Error in navigation logic: " + ex.getMessage());
		        		    refreshFileExplorer();
		        		}
		 
		         });

	       
	         
	         
	         // Add mouse listener for right-click popup on fileList
	         fileList.addMouseListener(new MouseAdapter() {
	             @Override
	             public void mousePressed(MouseEvent e) {
	                 if (SwingUtilities.isRightMouseButton(e)) {
	                	//popupMenu.show(e.getComponent(), e.getX(), e.getY());
	                	 System.out.println("Right click pressed");
	                	 
	                	 File selectedFile = fileList.getSelectedValue();
	                	 
	                	 if(selectedFile != null) {
	                		 
	                		// Get the folder name
	 	         	        String folderName = selectedFile.toString();
	 	         	      
	 	         	        
	 	                	 //System.out.println("Right click listener is directory "+selectedFile.isDirectory()+" "+selectedFile.toString()+" isNull "+(selectedFile != null));
	 	                	 
	 	         	        //Add a slash to the end and check if the string is in the folder list which means it is a folder and not a file
	 	         	        if(folders.contains(folderName+"/")) {
	 	                			 showContextMenu(e,folderNameSelected);
	 	                		 
	 	                	 }
	                	 }
	                	 
	                 }
	             }
	         });
	         
	         //left-click
	         fileList.addMouseListener(new MouseAdapter() {
	        	    @Override
	        	    public void mouseClicked(MouseEvent e) {
	        	        if (SwingUtilities.isLeftMouseButton(e)) {
	        	            // Handle left mouse button clicks
	        	        	if(verbose) {
		        	        	System.out.println("Left mouse pressed");

	        	        	}	        	        	
	        	            if (e.getClickCount() == 2) { // Double-click logic
	        	                int index = fileList.locationToIndex(e.getPoint());

	        	                if (index >= 0) {
	        	                    Object selectedItem = fileList.getModel().getElementAt(index);
	        	                    String folderNameSelected = selectedItem.toString();
	        	                    
	        	                    // Check if the selected item is a folder
	        	                    if (folders.contains(folderNameSelected + "/")) {
	        	                        // Navigate into the folder
	        	                        navigateTo(folderNameSelected + "/");
	        	                    } else {
	        	                        System.out.println("Double-clicked item is not a folder.");
	        	                    }
	        	                }
	        	            }
	        	        }
	        	        else if (SwingUtilities.isRightMouseButton(e)) {
	        	            // Handle right mouse button clicks
	        	            int index = fileList.locationToIndex(e.getPoint());
	        	            
	        	            if (index >= 0) {
	        	                Object selectedItem = fileList.getModel().getElementAt(index);
	        	                String folderNameSelected = selectedItem.toString();

	        	                // Check if the selected item is a folder
	        	                if (folders.contains(folderNameSelected + "/")) {
	        	                    showContextMenu(e, folderNameSelected);
	        	                }
	        	            }
	        	        }
	        	    }
	        	});
	         //Double-click listener on the file list to open folders or preview files
	        
	         fileList.addMouseListener(new MouseAdapter() {
	             @Override
	             public void mouseClicked(MouseEvent e) {
	                 if (e.getClickCount() == 2) {
	                	 if(verbose) {
	                		 System.out.println("Double click pressed");
	                	 }
	                	 
	                	 File selectedFile = fileList.getSelectedValue();
	                	 
	                	 if (selectedFile != null) {
	                    	 
	                    	 //for(String folderName:files) {
	                    	//	 System.out.println(folderName);
	                    	 //}
	                    	 
	                    	 
	                         if (folders.contains(selectedFile.toString()+"/")) {//selectedFile.isDirectory()
	                        	// navigateTo(selectedFile);
	                        	 //navigateTo(selectedFile.toString()); 
	                        	 //add to the stack
	                        	 currentFile=selectedFile.toString();
	                        	 String currentDirectory = ("/Users/tavoygordon/temp");
	                        	 displayCurrentDirectory(containerName);
	                        	 // Print the current directory
	                        	 stackNav= new FileBrowserNavigation(currentDirectory) ;
	                        	 stackNav.navigateTo(selectedFile.toString());
	                        	 System.out.println("Current Directory: " + stackNav.getCurrentDirectory());
	                        	 //System.out.println("Double click IF IF " + selectedFile.toString());
	                        	listFolderContents(selectedFile.toString());
	                        	//System.out.println(selectedFile.toString());
	                        	 if(verbose) {
	                        		 System.out.println("Testing Stack");
	                        	
	                        	 }
	                         } 
	                         else {
	                        	 //TODO: Update this method to handle files
	                        	 //selectedFile = fileList.getE
	                        	 
	                        	 //System.out.println("Double click IF ELSE");
	                        	 
	                        	 String blobName = files.get(fileList.getSelectedIndex());
	                	         
	                	         //String blobUrl = storageAccountUrl + containerNameFixed + "/" + blobName;
	                        	 
	                        	 BlobClientBase blobClient = containerClient.getBlobClient(blobName).getBlockBlobClient();
	                        	 
	                        	// Load the blob into memory
	                             try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
	                                 blobClient.download(outputStream);
	                                 byte[] blobBytes = outputStream.toByteArray();

	                                 // Create a temporary file in memory
	                                 selectedFile = File.createTempFile(getFileName(blobName), "."+getFileHeader(blobClient));
	                                 if(verbose) {
	                                	 System.out.println("File Type: "+getFileHeader(blobClient));
	                                 //selectedFile = File.createTempFile(getFileName(blobName), "."+getFileHeader(blobClient));
	                                 } 
	                                 Files.write(selectedFile.toPath(), blobBytes);

	                                 // tempFile now holds the blob data
	                                 if(verbose) {
	                                	 System.out.println("Loaded blob into in-memory file: " + selectedFile.getAbsolutePath());
	                                 }
	                                 // Delete the temporary file on exit if necessary
	                                 selectedFile.deleteOnExit();
	                             } catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
	                        	 
	                             //Check if file exist locally	                             
	                             checkAndHandleFile(containerClient, blobName);

	                             
	                          // Simulating double-click action
	                           openFileOnDoubleClick(selectedFile);
	                             
	                        	 //selectedFile = new File(files.get(fileList.getSelectedIndex()));
	                        	 //selectedFile = new File(blobClient.);
	                        	 
	                        	 //System.out.println("IsFile: "+selectedFile.isFile()+" Exists: "+selectedFile.exists());
	                           //displayFilePreview(selectedFile.getParent());
	                             displayFilePreview(selectedFile);
	                         }
	                     }
	                 }
	             }
	         });
	         
	         //Call method to check folder
	         folderChecker.CheckAndCreateFolder();
	         refreshFileExplorer();
	         setVisible(true);
	         navigateTo(""); 
	       
	     }
	    private void navigateTo(String folderPath) {
	        navigationStack.navigateTo(folderPath);
	       //displayFolderContents(folderPath);
	        
	    }
	    
	    
	    
	    
	    
	    
	    private void updateFileList(String directory) {
	        // Use Azure APIs to list blobs within the "directory"
	        System.out.println("Fetching blobs for directory: " + directory);

	        PagedIterable<BlobItem> blobs = containerClient.listBlobsByHierarchy(directory + "/");

	        List<String> fileList = new ArrayList<>();
	        for (BlobItem blob : blobs) {
	            String blobName = blob.getName();
	            if (blobName.startsWith(directory) && !blobName.equals(directory)) {
	                // Remove parent directory prefix
	                String relativeName = blobName.substring(directory.length());
	                if (relativeName.startsWith("/")) {
	                    relativeName = relativeName.substring(1); // Clean leading slash
	                }
	                fileList.add(relativeName);
	            }
	        }

	        // Update GUI component (e.g., JList or JTable) with the new file list
	        updateGUIFileList(fileList);
	       // displayFileMetadata(files);
	    }

	    
	 // Dummy method to update the GUI component
	    private void updateGUIFileList(List<String> fileList) {
	        System.out.println("Updating GUI with files: " + fileList);
	        // Implement logic to populate your file list UI
	    }
	    
	    public void displayCurrentDirectory(String containerName) {
	        try {
	            // Get the container client
	            BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(containerName);
	            // Check if container exists
	            if (!containerClient.exists()) {
	                System.out.println("Container does not exist: " + containerName);
	                return;
	            }

	            // List blobs in the container
	            System.out.println("Contents of container: " + containerName);
	            for (BlobItem blobItem : containerClient.listBlobs()) {
	                System.out.println("- " + blobItem.getName());
	            }
	        } catch (Exception e) {
	            System.out.println("Error displaying current directory: " + e.getMessage());
	        }
	    }


    				//Divide and Conquer method (Analysis of Algorithm Category) 

    	    public void checkFilesDivideAndConquer(BlobContainerClient containerClient, List<String> blobNames) {
    	        if (blobNames == null || blobNames.isEmpty()) {
    	            return; // Base case: empty list, nothing to process
    	        }

    	        // Base case: If there's only one file, process it
    	        if (blobNames.size() == 1) {
    	            checkAndHandleFile(containerClient, blobNames.get(0));
    	            return;
    	        }

    	        // Divide the list into two halves
    	        int mid = blobNames.size() / 2;
    	        List<String> left = blobNames.subList(0, mid);
    	        List<String> right = blobNames.subList(mid, blobNames.size());

    	        // Conquer: Process each half recursively
    	        checkFilesDivideAndConquer(containerClient, left);
    	        checkFilesDivideAndConquer(containerClient, right);
    	    }

    	    /*private void checkAndHandleFile(BlobContainerClient containerClient, String blobName) {
    	        try {
    	            File localFile = new File(localPath, getFileName(blobName));

    	            // Check if the file exists locally
    	            if (localFile.exists()) {
    	                System.out.println("File exists locally: " + localFile.getAbsolutePath());
    	                openFileOnDoubleClick(localFile);
    	            } else {
    	                System.out.println("File does not exist locally. Downloading from Azure Blob Storage...");
    	                downloadAndOpenFile(containerClient, blobName);
    	            }
    	        } catch (IOException e) {
    	            e.printStackTrace();
    	        }
    	    }*/
    	    private void checkAndHandleFile(BlobContainerClient containerClient, String blobName) {
    	        try {
    	            // Ensure the directory exists
    	            File folder = new File(localPath);
    	            if (!folder.exists()) {
    	                folder.mkdirs();
    	            }

    	            // Check if the file exists in the local directory
    	            File localFile = new File(folder, getFileName(blobName));
    	            if (localFile.exists()) {
    	                System.out.println("File exists locally: " + localFile.getAbsolutePath());
    	                //openFileOnDoubleClick(localFile);
    	            } else {
    	                System.out.println("File does not exist locally. Downloading from Azure Blob Storage...");
    	                downloadAndOpenFile(containerClient, blobName);
    	            }
    	            
    	         // After processing the file, check folder size
    	            checkAndEnforceSizeLimit(new File(localPath));
    	            
    	        } catch (IOException e) {
    	            e.printStackTrace();
    	        }
    	    }

    	    
    	    
    	    private void downloadAndOpenFile(BlobContainerClient containerClient, String blobName) throws IOException {
    	        BlobClientBase blobClient = containerClient.getBlobClient(blobName).getBlockBlobClient();

    	        // Download blob
    	        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
    	            blobClient.download(outputStream);
    	            byte[] blobBytes = outputStream.toByteArray();

    	            // Ensure the directory exists
    	            File folder = new File(localPath);
    	            if (!folder.exists()) {
    	                folder.mkdirs();
    	            }

    	            // Create the file in the local directory
    	            File downloadedFile = new File(folder, getFileName(blobName));
    	            Files.write(downloadedFile.toPath(), blobBytes);

    	            System.out.println("Downloaded and created file: " + downloadedFile.getAbsolutePath());

    	            // Open the file
    	            //openFileOnDoubleClick(downloadedFile);
    	        }
    	    }
    	    
    	   
    	 // Check if folder exceeds size limit and enforce management
    	    private void checkAndEnforceSizeLimit(File folder) {
    	        long totalSize = calculateTotalSize(folder);
    	        if (totalSize > sizeLimit) {
    	            System.out.println("Total size exceeds limit! Managing folder contents...");
    	            // Calculate how much space needs to be freed
    	            long excessSize = totalSize - sizeLimit;

    	            // Delete files until we are within the size limit
    	            int filesToDelete = calculateFilesToDelete(folder, excessSize);
    	            deleteOldestKItems(folder, filesToDelete);

    	            // Notify the user
    	            showUserNotification("Folder size exceeded the limit. Oldest files have been deleted to free up space.");
    	        } else {
    	            System.out.println("Total size is within the limit.");
    	        }
    	    }
    	    
    	 // Calculate the total size of the folder contents
    	    private long calculateTotalSize(File folder) {
    	        long totalSize = 0;
    	        if (folder.isDirectory()) {
    	            for (File file : folder.listFiles()) {
    	                totalSize += file.length();
    	            }
    	        }
    	        return totalSize;
    	    }
    	    
    	 // Calculate how many files need to be deleted to free up the excess space
    	    private int calculateFilesToDelete(File folder, long excessSize) {
    	        File[] files = folder.listFiles();
    	        if (files == null) return 0;

    	        Arrays.sort(files, Comparator.comparingLong(File::lastModified)); // Sort by date ascending	        
    	         
    	       // Arrays.sort(files, (file1, file2) -> Long.compare(file1.lastModified(), file2.lastModified()));

    	        
    	        long freedSize = 0;
    	        int filesToDelete = 0;
    	        for (File file : files) {
    	        	System.out.println("File "+file.getName());
    	        	
    	            freedSize += file.length();
    	            filesToDelete++;
    	            if (freedSize >= excessSize) {
    	                break;
    	            }
    	        }
    	        return filesToDelete;
    	    }
    	 // Delete the oldest K items in the folder
    	    public static void deleteOldestKItems(File folder, int K) {
    	        File[] files = folder.listFiles();
    	        if (files == null || files.length <= K) return;

    	       Arrays.sort(files, Comparator.comparingLong(File::lastModified)); // Sort by date ascending
    	       // Arrays.sort(files, (file1, file2) -> Long.compare(file1.lastModified(), file2.lastModified()));
    	       
    	        for (int i = 0; i < K; i++) {
    	          System.out.println("Deleting file: " + files[i].getAbsolutePath());
    	            files[i].delete();
    	        }
    	    }

    	    // Show a friendly notification in the GUI
    	    private void showUserNotification(String message) {
    	        SwingUtilities.invokeLater(() -> {
    	            JOptionPane.showMessageDialog(null, message, "Folder Management ⚠️", JOptionPane.INFORMATION_MESSAGE);
    	        });
    	    }

    	   
    	    

    	    private boolean isFolderEmpty(File folder) {
    	        if (folder.exists() && folder.isDirectory()) {
    	            File[] files = folder.listFiles();
    	            return files == null || files.length == 0;
    	        }
    	        return true;
    	    }
    	    
     

	    private void listFolderContents(String folderName) {
	        // Clear the current list model
	        //files.clear();
	        //folders.clear();
	    	fileListModel.clear();
	    	
	    	//System.out.println("List folders");
	    	/*
	    	azureBlobStorage.getFilesAndDirectories();
	        
	        files = azureBlobStorage.getFiles();
	        folders = azureBlobStorage.getFolders();*/
	    	String[] myfile;
	    	
	    	

	        // List all blobs inside the selected folder
	        for (String folder: folders) {
	    	//BlobClientBase blobItem = this.containerClient.getBlobClient(folderName).getPageBlobClient();
	    	
	            //String itemName = blobItem.getBlobName();
	            //System.out.println("Folders "+folder+" foldername "+folderName);
	            
	         // Create a File object for each file name
	            File file = new File(folder);
	            
	            
	        	
	            if (folder.contains(folderName)) {  // It's a sub-folder
	            	//System.out.println("IF");
	                
	            	fileListModel.addElement(file);
	                break;
	            }
	        }
	        for (String fileHolder: files) {
		    	//BlobClientBase blobItem = this.containerClient.getBlobClient(folderName).getPageBlobClient();
		    	
		            //String itemName = blobItem.getBlobName();
		            //System.out.println("Folders "+folder);
		            
		            
		            if (fileHolder.contains(folderName)) {  // It's a sub-folder
		            	
		            	
			            
			         // Extract the filename using substring and lastIndexOf
			            String filename = fileHolder.substring(fileHolder.lastIndexOf("/") + 1);
			         
			            // Create a File object for each file name
			            File file = new File(filename);
			            
		                fileListModel.addElement(file);
		            }
		        }
	    }
	    
	    private void showContextMenu(MouseEvent e, String folderName) {
	    	//folderNameSelected=folderName;
	    	//System.out.println(folderNameSelected);
	        // Create popup menu
	        JPopupMenu contextMenu = new JPopupMenu();

	        // "Create Folder" menu item
	        JMenuItem createFolderItem = new JMenuItem("Create Folder");
	        createFolderItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent event) {
	            	createFolder();  // Call create folder method
	            }
	        });
	        contextMenu.add(createFolderItem);

	        // "Upload File" menu item
	        JMenuItem uploadFileItem = new JMenuItem("Upload File");
	        uploadFileItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent event) {
	                uploadFileToFolder(folderName);  // Call upload file method
	            }
	        });
	        contextMenu.add(uploadFileItem);

	        // "Download Folder/File" menu item
	        JMenuItem downloadItem = new JMenuItem("Download Folder/File");
	        downloadItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent event) {
	                downloadFolderOrFile(folderName);  // Call download method
	            }
	        });
	        contextMenu.add(downloadItem);

	        // Show popup menu at the mouse click location
	        contextMenu.show(e.getComponent(), e.getX(), e.getY());
	    }
	    
	    
	    // Default folder method to check and create folder on local machine to store files
	    public class FolderCheckAndCreate {

	        public void CheckAndCreateFolder() {
	        	//path to downlaod folder
	            String folderPath = "/Users/tavoygordon/temp"; 
	            File folder = new File(folderPath);

	            if (!folder.exists()) {
	                if (folder.mkdirs()) {
	                    System.out.println("Folder created: " + folderPath);
	                } else {
	                    System.out.println("Failed to create folder: " + folderPath);
	                }
	            } else {
	                System.out.println("Folder already exists: " + folderPath);
	            }
	        }

	        
	    }
	    
	    
	    // Function to read the first N bytes of a blob
	    private static byte[] readBlobHeader(BlobClientBase blobClient, int length) throws IOException {
	    	// Get blob properties to determine its actual size
	        BlobProperties properties = blobClient.getProperties();
	        long blobSize = properties.getBlobSize();

	        // Adjust the length if the blob is smaller than the requested range
	        int bytesToRead = (int) Math.min(length, blobSize);
	        BlobRange range = new BlobRange(0, (long) bytesToRead); // Specify range: start 0, length `bytesToRead`

	        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	        blobClient.downloadStreamWithResponse(outputStream, range, null, null, false, null, null);
	        //System.out.println("Header "+outputStream.toByteArray().toString());
	        return outputStream.toByteArray();
	    }

	    // Convert byte array to hex string
	    private static String bytesToHex(byte[] bytes) {
	        StringBuilder hexString = new StringBuilder();
	        for (byte b : bytes) {
	            hexString.append(String.format("%02X", b));
	        }
	        //System.out.println("HexStr "+ hexString.toString()+"\n");
	        return hexString.toString();
	    }
	    
	    public String getFileHeader(BlobClientBase blobClient) {
	    	
            
            //BlobClientBase blobClient = containerClient.getBlobClient(blobName).getBlockBlobClient();
            
	    	String fileType = "Unknown format";
	    	
	 

	            try {
	                // Read the first 8 bytes (adjust based on the longest magic number)
	                byte[] header = readBlobHeader(blobClient, 8);
	                String hexMagicNumber = bytesToHex(header);
	                
	                
	                if (hexMagicNumber.startsWith("504B0304")) {
	                    // Likely a ZIP-based format (DOCX, XLSX, PPTX, or other)
	                    // Download a larger header to inspect for folder structure
	                    byte[] extendedHeader = readBlobHeader(blobClient, 2048);
	                    String extendedHeaderStr = new String(extendedHeader);
	                    
	                    //System.out.println("Extended Header "+ extendedHeaderStr.toString());
	                    
	                    if (extendedHeaderStr.contains("word/document.xml")) {
	                        return "DOCX";
	                    } else if (extendedHeaderStr.contains("xl/_rels/workbook.xml")) {
	                        return "XLSX";
	                    } else if (extendedHeaderStr.contains("_rels/.rels")) {
	                        return "PPTX";
	                    } else {
	                        return "ZIP";
	                    }
	                }

	                // Check for PDF format
	                if (hexMagicNumber.startsWith("255044")) {
	                    return "PDF";
	                }
	             // Check for legacy Office formats (e.g., DOC, XLS, PPT)
	                if (hexMagicNumber.startsWith("D0CF11E0")) {
	                    // Additional content inspection is required to determine if it's specifically PPT
	                    return "PPT";
	                }
	                // Check for legacy Office formats (e.g., DOC, XLS, PPT)
	                if (hexMagicNumber.startsWith("D0CF11E0")) {
	                    return "Microsoft Office Binary (DOC, XLS, PPT)";
	                    //"Microsoft Office Binary (DOC, XLS, PPT)"
	                }
	                if (hexMagicNumber.contains("776F726B") || hexMagicNumber.contains("73686565")) {
	                     return "XLSX";
	                 }
	                
	             // Search specifically for the "66747970" (ftyp) signature within the first 64 bytes
	                 if (hexMagicNumber.contains("66747970")) {
	                     return "MP4";
	                 }
	                 if (hexMagicNumber.contains("89504E47")) {
	                     return "png";
	                 }
 	        		if (hexMagicNumber.contains("47494638")) {
	                     return "gif";
	                 }
 	        		if (hexMagicNumber.contains("424D")) {
	                     return "bmp";
	                 }
 	        		if (hexMagicNumber.contains("49492A00")|| hexMagicNumber.contains("4D4D002A"))  {
	                     return "tiff";
	                 }
 	        		
 	        		 if (hexMagicNumber.contains("66747970")) {
	                     return "mp4";
	                 }
	                 if (hexMagicNumber.contains("494433")|| hexMagicNumber.contains("FFFB") || hexMagicNumber.contains("FFF3")) {
	                     return "mp3";
	                 }
	                 if (hexMagicNumber.contains("52494646")) {
	                     return "wav";
	                 }
	                 if (hexMagicNumber.contains("664C6143")) {
	                     return "flac";
	                 }
	                 if (hexMagicNumber.contains("41564920")) {
	                     return "avi";
	                 }
	                 if (hexMagicNumber.contains("1A45DFA3")) {
	                     return "mkv";
	                 }
	                 
	                 // Check for Microsoft Office Open XML format (PPTX, DOCX, XLSX)
		                /*if (hexMagicNumber.startsWith("504B0304")) {
		                    // For more precision, unzip and look for the "ppt" directory
		                    return "PPTX";
		                }*/

	                

	                // Check magic number against known types
	                //fileType = MAGIC_NUMBERS.getOrDefault(hexMagicNumber, "Unknown format");
	                //TODO To remove
	                //System.out.println("File: " + blobClient.getBlobName() + " Type: " + fileType +" "+hexMagicNumber.toString());
	                //inspectHeader(header);

	            } catch (IOException e) {
	                System.out.println("Failed to read blob header for file: " + blobClient.getBlobName());
	                e.printStackTrace();
	            }
	        
	    	return fileType;
	    }
	    
	
	    public void openFileOnDoubleClick(File file) {
	        // Check if the file exists
	        if (file.exists() && file.isFile()) {
	            // Get the file type
	            String fileType = "";
	            
				try {
					fileType = getFileType(file);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

	            try {
	                // Use Desktop to open the file if supported
	                if (Desktop.isDesktopSupported()) {
	                    Desktop desktop = Desktop.getDesktop();
	                    
	                    if (desktop.isSupported(Desktop.Action.OPEN)) {
	                        System.out.println("Opening file with default application for type: " + fileType);
	                        desktop.open(file);
	                    } else {
	                        System.out.println("Open action is not supported on this platform.");
	                    }
	                } else {
	                    System.out.println("Desktop API is not supported on this platform.");
	                }
	            } catch (IOException e) {
	                System.out.println("Error opening the file: " + e.getMessage());
	            }
	        } else {
	            System.out.println("File does not exist or is not a file.");
	        }
	    }
	 // Method to update the file list
	    public void updateFileList(List<String> files) {
	        fileListPanel.removeAll(); // Clear current list of files

	        // Add each file as a label or component to the panel
	        for (String fileName : files) {
	            JLabel fileLabel = new JLabel(fileName);
	            fileListPanel.add(fileLabel);
	        }

	        // Refresh the panel to display new content
	        fileListPanel.revalidate();
	        fileListPanel.repaint();
	    }
	    
	    private void loadFolders() {
	        // Clear the current list
	    	folders.clear();
	        folderListModel.clear();

	        // Fetch folders from Azure Blob Storage
	        folders = azureBlobStorage.getFolders();

	        // Add each folder to the GUI list model
	        for (String folder : folders) {
	            folderListModel.addElement(folder);
	        }
	    }
	    
	    
	    private String getFileName(String fileName) {
	    	
	    	String[] myfile;
	    	
	    	myfile = fileName.split("/");
        	if(myfile.length >1) {
        		fileName = myfile[myfile.length - 1];
        	}else {
        		fileName = myfile[0];
        	}
	    	
	    	return fileName;
	    }
	    
	    public void searchFileFolder(String stringSearch) {
	        // Ensure the list models are cleared
	        fileListModel.clear();

	        // Fetch data from Azure Blob Storage only if necessary
	        if (files.isEmpty() || folders.isEmpty()) {
	            azureBlobStorage.getFilesAndDirectories();
	            files = azureBlobStorage.getFiles();
	            folders = azureBlobStorage.getFolders();
	        }

	        // Convert search string to lowercase for case-insensitive comparison
	        String lowerCaseSearch = stringSearch.toLowerCase();
	        HashSet<String> addedItems = new HashSet<>();

	        // Search in files
	        for (String fileName : files) {
	            String lowerFileName = fileName.toLowerCase();

	            if (lowerFileName.contains(lowerCaseSearch)) {
	                String[] myfile = fileName.split("/");
	                String displayName = myfile.length > 1 ? myfile[myfile.length - 1] : myfile[0];

	                if (!addedItems.contains(displayName)) {
	                    File file = new File(displayName);
	                    fileListModel.addElement(file);
	                    addedItems.add(displayName);
	                }
	            }
	        }

	        // Search in folders
	        for (String folderName : folders) {
	            String lowerFolderName = folderName.toLowerCase();

	            if (lowerFolderName.contains(lowerCaseSearch)) {
	                if (!addedItems.contains(folderName)) {
	                    File folder = new File(folderName);
	                    fileListModel.addElement(folder);
	                    addedItems.add(folderName);
	                }
	            }
	        }
	    }

	    
	    public void refreshFileExplorer() {
	    	//System.out.println("refreshFileExplorer");
	    	
	    	//Clear the files and folders list in order to prevent duplicates when you refresh file explorer
	    	files.clear();
	    	folders.clear();
	    	
	        fileListModel.clear(); // Clear existing items

	        // Fetch files and folders from Azure Blob Storage
	        azureBlobStorage.getFilesAndDirectories();
	        
	        files = azureBlobStorage.getFiles();
	        folders = azureBlobStorage.getFolders();
	        
	        String[] myfile;
	        
	        for (String fileName : files) {
	        	//System.out.println("Contains folders "+fileListModel.contains(fileName)+" "+fileName);
	                
	            if(!(fileListModel.contains(fileName))){
	            	myfile = fileName.split("/");
	            	if(myfile.length >1) {
	            		fileName = myfile[myfile.length - 1];
	            	}else {
	            		fileName = myfile[0];
	            	}
	            	
	            	// Create a File object for each file name
		            File file = new File(fileName);
		            
		            // Add the File object to the model
		            fileListModel.addElement(file);
	            }
	            
	            //System.out.println("FName "+ fileName);
	            
            	
	        }
	        for (String folderName : folders) {
	        	//System.out.println("Contains folders "+fileListModel.contains(folderName)+" "+folderName);
	        	// Create a File object for each file name
	        	if(!(fileListModel.contains(folderName))){
	        		File file = new File(folderName);
		            
		            
		            // Add the File object to the model
		            fileListModel.addElement(file);
	        	}
	        	
	        }
	        
	        //updateFileList(filesAndDirs);
	    }
	    
	      // Method to create a new folder
	         private void createFolder() {
	             String folderName = JOptionPane.showInputDialog(this, "Enter Folder Name:", "Create Folder", JOptionPane.PLAIN_MESSAGE);

	             if (folderName != null && !folderName.trim().isEmpty()) {
	                 // Add a "/" to the end of folder name to signify it's a folder
	                 String blobFolderName = folderName + "/";

	                 // Create a blob client for the folder
	                 BlobClient blobClient = containerClient.getBlobClient(blobFolderName);

	                 // Upload empty content to create the "folder"
	                 blobClient.upload(new ByteArrayInputStream(new byte[0]), 0);
	                 refreshFileExplorer();

	                 JOptionPane.showMessageDialog(this, "Folder created: " + folderName, "Folder Creation", JOptionPane.INFORMATION_MESSAGE);
	             } else {
	                 JOptionPane.showMessageDialog(this, "Folder name cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
	             }
	         

	         // Additional helper methods (e.g., for file metadata, file preview) would go here.
	     }
	         
	      // Method to upload a file to the specified folder
	         private void uploadFileToFolder(String folderName) {
	             JFileChooser fileChooser = new JFileChooser();
	             int option = fileChooser.showOpenDialog(this);
	             if (option == JFileChooser.APPROVE_OPTION) {
	                 File file = fileChooser.getSelectedFile();
	                 if (file != null) {
	                     AzureBlobStorage azureBlobStorage = this.azureBlobStorage;
	                     azureBlobStorage.uploadFile(folderName, file);
	                     JOptionPane.showMessageDialog(this, "File uploaded successfully!");
	                 }
	             }
	             refreshFileExplorer();
	         }
	         
	      // Method to download a folder or file
	        
	         
	         private void downloadFolderOrFile(String folderName) {
	        	    JFileChooser directoryChooser = new JFileChooser();
	        	    directoryChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	        	    int option = directoryChooser.showSaveDialog(this);

	        	    if (option == JFileChooser.APPROVE_OPTION) {
	        	        File localDirectory = directoryChooser.getSelectedFile();
	        	        String localDirectoryPath = localDirectory.getAbsolutePath();

	        	        // Download the selected file or folder to the specified local directory
	        	        azureBlobStorage.downloadFileOrFolder(folderName, localDirectoryPath);
	        	        JOptionPane.showMessageDialog(this, "Download completed!");
	        	    }
	        	}
	   
	     // -------------------------------------------------------------------------
	     // Creating a hash map to hold a few file types and their coresponding magic numbers
	     // -------------------------------------------------------------------------
	     private static final Map<String, String> MAGIC_NUMBERS = new HashMap<>();
	     static {
	    	 
	         // some basic photo file types
	    	 /*
	         MAGIC_NUMBERS.put("FFD8FF", "JPEG Image");
	         MAGIC_NUMBERS.put("89504E47", "PNG Image");
	         MAGIC_NUMBERS.put("47494638", "GIF Image");
	         MAGIC_NUMBERS.put("25504446", "PDF Document");
	         MAGIC_NUMBERS.put("424D", "BMP Image");
	         MAGIC_NUMBERS.put("49492A00", "TIFF Image (little-endian)");
	         MAGIC_NUMBERS.put("4D4D002A", "TIFF Image (big-endian)");
	   
	          // Audio and Video Types
	         MAGIC_NUMBERS.put("66747970", "MP4"); // MP4/MOV (ftyp)
	         MAGIC_NUMBERS.put("494433", "MP3"); // MP3 (ID3v2)
	         MAGIC_NUMBERS.put("FFFB", "MP3"); // MP3 (MPEG Header)
	         MAGIC_NUMBERS.put("FFF3", "MP3"); // MP3 (MPEG Header)
	         MAGIC_NUMBERS.put("52494646", "WAV"); // WAV/AVI (RIFF)
	         MAGIC_NUMBERS.put("41564920", "AVI"); // AVI
	         MAGIC_NUMBERS.put("664C6143", "FLAC"); // FLAC (fLaC)
	         MAGIC_NUMBERS.put("1A45DFA3", "MKV"); // MKV (EBML)
	         MAGIC_NUMBERS.put("494433", "MP3 Audio");
	         MAGIC_NUMBERS.put("52494646", "WAV Audio");
				*/
	    	 MAGIC_NUMBERS.put("FFD8FF", "image/jpeg");
	         MAGIC_NUMBERS.put("89504E47", "image/png");
	         MAGIC_NUMBERS.put("47494638", "image/gif");
	         MAGIC_NUMBERS.put("25504446", "PDF Document");
	         MAGIC_NUMBERS.put("424D", "image/bmp");
	         MAGIC_NUMBERS.put("49492A00", "image/tiff");// (little-endian)
	         MAGIC_NUMBERS.put("4D4D002A", "image/tiff");//(big-endian)
	   
	          // Audio and Video Types
	         MAGIC_NUMBERS.put("66747970", "video/mp4"); // MP4/MOV (ftyp)
	         MAGIC_NUMBERS.put("494433", "audio/mp3"); // MP3 (ID3v2)
	         MAGIC_NUMBERS.put("FFFB", "audio/mp3"); // MP3 (MPEG Header)
	         MAGIC_NUMBERS.put("FFF3", "audio/mp3"); // MP3 (MPEG Header)
	         MAGIC_NUMBERS.put("52494646", "audio/wav"); // WAV/AVI (RIFF)
	         MAGIC_NUMBERS.put("41564920", "audio/avi"); // AVI
	         MAGIC_NUMBERS.put("664C6143", "audio/flac"); // FLAC (fLaC)
	         MAGIC_NUMBERS.put("1A45DFA3", "video/mkv"); // MKV (EBML)
		     
		        
	         // Basic document types
	         //MAGIC_NUMBERS.put("D0CF11E0A1B11AE1", "DOC");
	         //MAGIC_NUMBERS.put("504B0304", "DOCX"); 
	         MAGIC_NUMBERS.put("D0CF11E0", "Microsoft Office (DOC, XLS, ppt)"); // Compound File Binary Format
	         MAGIC_NUMBERS.put("504B0304", "Microsoft Office/ZIP Archive (DOCX, XLSX, pptx)"); // ZIP-based formats
	         MAGIC_NUMBERS.put("0x00000000", "Open Document Format (ODT, ODS, ODP)"); // ODF files (general case)
	         MAGIC_NUMBERS.put("7B5C7274", "RTF Document");
	         MAGIC_NUMBERS.put("D0CF11E0", "Microsoft PowerPoint Binary (PPT)");
	         MAGIC_NUMBERS.put("776F726B", "Microsoft Excel Open XML (XLSX)");
	     }
	     

	     // -------------------------------------------------------------------------
	     // Creating a method that is able to detect the file type based on it's magic number
	     // -------------------------------------------------------------------------
	     private String getFileType(File file) {
	         // Return "Directory" if the file is actually a directory
	         if (file.isDirectory()) {
	             return "Directory";
	         }
	         //System.out.println("getFileType");
	         // Attempt to read the file's magic number

        	 String blobName = files.get(fileList.getSelectedIndex());
	         
	         //String blobUrl = storageAccountUrl + containerNameFixed + "/" + blobName;
        	 
        	 BlobClientBase blobClient = containerClient.getBlobClient(blobName).getBlockBlobClient();
        	 
	         try (InputStream inputStream = blobClient.openInputStream()) {
	             byte[] bytes = new byte[64]; // Read first 16 bytes for broader magic number matching
	             if (inputStream.read(bytes) != -1) {
	                 StringBuilder hex = new StringBuilder();
	                 for (byte b : bytes) {
	                     hex.append(String.format("%02X", b));
	                 }
	                 
	                
	    	     
	              System.out.println("GetFileType "+hex.toString());
	              
	             
	              // Search specifically for the "66747970" (ftyp) signature within the first 64 bytes
	 	        		
	 	        		
	 	        		if (hex.toString().contains("25504446")) {
		                     return "pdf";
		                 }
	 	        		
	 	        	
	                
	                 if (hex.toString().contains("776F726B") || hex.toString().contains("73686565")) {
	                     return "XLSX";
	                 }
	                 if (hex.toString().startsWith("504B0304")) {
		                    // Likely a ZIP-based format (DOCX, XLSX, PPTX, or other)
		                    // Download a larger header to inspect for folder structure
		                    byte[] extendedHeader = readBlobHeader(blobClient, 2048);
		                    String extendedHeaderStr = new String(extendedHeader);
		                    
		                    if (extendedHeaderStr.contains("word/document.xml")) {
		                        return "DOCX";
		                    } else if (extendedHeaderStr.contains("xl/_rels/workbook.xml")) {
		                        return "XLSX";
		                    } else if (extendedHeaderStr.contains("_rels/.rels")) {
		                        return "PPTX";
		                    } else {
		                        return "ZIP";
		                    }
		                }
	                 
	                 if (hex.toString().contains("89504E47")) {
	                     return "png";
	                 }
 	        		if (hex.toString().contains("47494638")) {
	                     return "gif";
	                 }
 	        		if (hex.toString().contains("424D")) {
	                     return "bmp";
	                 }
 	        		if (hex.toString().contains("49492A00")|| hex.toString().contains("4D4D002A"))  {
	                     return "tiff";
	                 }
 	        		
 	        		 if (hex.toString().contains("66747970")) {
	                     return "mp4";
	                 }
	                 if (hex.toString().contains("494433")|| hex.toString().contains("FFFB") || hex.toString().contains("FFF3")) {
	                     return "mp3";
	                 }
	                 if (hex.toString().contains("52494646")) {
	                     return "wav";
	                 }
	                 if (hex.toString().contains("664C6143")) {
	                     return "flac";
	                 }
	                 if (hex.toString().contains("41564920")) {
	                     return "avi";
	                 }
	                 if (hex.toString().contains("1A45DFA3")) {
	                     return "mkv";
	                 }
	                 
	                 /*
	                 if (hex.toString().contains("504B03") || hex.toString().contains("504B05") || hex.toString().contains("504B07")) {
	                	    return "ZIP";
	                	}*/
	                 
	                 if (hex.toString().contains("D0CF11E0")) {
	                	    return "PPT";
	                	}

	                 
	                 // Check if the file's magic number matches any known file types
	                 for (Map.Entry<String, String> entry : MAGIC_NUMBERS.entrySet()) {
	                	 //System.out.println("Het2Str "+ hex.toString()+" "+entry.getKey());
	                	 
	                     if (hex.toString().startsWith(entry.getKey())) {
	                         return entry.getValue(); // Return the matched file type
	                     }
	                 }
	             }
	         } catch (IOException e) {
	             e.printStackTrace();
	         }

	         return "Unknown Type"; // Return this if no match was found
	     }
	  

	     // -------------------------------------------------------------------------
	     // Display file preview (for text files, show the first few lines)
	     // -------------------------------------------------------------------------
	     
	 
	    private void displayFileMetadata(File file) {
	        StringBuilder metadata = new StringBuilder();
	        metadata.append("Name: ").append(file.getName()).append("\n");
	        metadata.append("Size: ").append(file.length()).append(" bytes\n");
	        metadata.append("Type: ").append(getFileType(file)).append("\n");
	        metadata.append("Last Modified: ")
	                .append(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(file.lastModified()))
	                .append("\n");
	        
	        String fileType = getFileType(file);
	        if(verbose) {
	        	System.out.println("File type detected: " + fileType);
	        }
	        if (file.isFile()) { //&& isSummarizable(file)) {
	            String summary = summarizeFile(file);
	            //String Summary = SummarizeFile (file);
	            metadata.append("Summary: ").append(summary).append("\n");
	        } else {
	            metadata.append("Summary: Not available for this file type.\n");
	        }
	        

	        // Update the GUI area with metadata
	        fileMetadataArea.setText(metadata.toString());
	    }
	    
	    private String summarizeFile(File file) {
	        try {
	            // Determine the file type
	            String fileType = Files.probeContentType(file.toPath());
	            String filePath = file.getAbsolutePath();
	            
	            /*if (fileType == null || fileType.isEmpty()) {
	                fileType = "application/octet-stream";  // Fallback MIME type
	            }*/

	            // Log file details for debugging
	            //System.out.println("Summarizing file: " + filePath + " with MIME type: " + fileType);
	            //if(verbose) {
	            	System.out.println("gemini type detected: " + fileType+" path:"+file.toPath());
	            //}
	            // Check if the file type is supported by Gemini (only images and audio/video for now)
	            if (isGeminiSupportedFileType(fileType)) {
	                // Summarize using Gemini if supported
	                System.out.println("Summarizing file using Gemini: " + filePath);
	                return GeminiAIAPI.summarizeContent(
	                    fileType, 
	                    filePath, 
	                    "chrome-mediator-442600-k1", 
	                    "us-central1", 
	                    "gemini-1.5-flash-001"
	                );
	            }

	            // If Gemini is not supported, fallback to OpenAI (ChatGPT) summarization
	            String content = extractFileContent(file);
	            if (content == null || content.isEmpty()) {
	                return "Content extraction failed or file is empty.";
	            }

	            // Limit content length for summarization to avoid sending too much data
	            String summaryText = content.length() > 5000 ? content.substring(0, 5000) : content;

	            // Call OpenAI for summarization
	            return OpenAIAPI.chatGPT("Summarize the following in less than 3 short sentences: " + summaryText);
	            
	        } catch (IOException e) {
	            return "Error reading file content or processing: " + e.getMessage();
	        } catch (Exception e) {
	            return "Unexpected error: " + e.getMessage();
	        }
	    }

	 // Helper method to check if the file type is supported by Gemini
	    private boolean isGeminiSupportedFileType(String fileType) {
	        System.out.println("isGeminiSupportedFileType call");

	        // Define supported file types for Gemini summarization (audio, video, and image files)
	        List<String> supportedTypes = Arrays.asList(
	            "audio/mp3",  // MP3 audio
	            "audio/wav",  // WAV audio
	            "video/mp4",  // MP4 video
	            "image/png",  // PNG image
	            "image/jpeg", // JPEG image
	            "image/gif",  // GIF image
	            "image/tiff", // TIFF image
	            "image/bmp"   // BMP image
	        );
	     // If file is an image, check for valid image extensions
	        if (isImageFile(new File(fileType))) {
	            return true;
	        }
	        return supportedTypes.contains(fileType);
	    }
	    private boolean isImageFile(File file) {
	        String fileName = file.getName().toLowerCase();
	        return fileName.endsWith(".png") || fileName.endsWith(".jpeg") || fileName.endsWith(".jpg")
	            || fileName.endsWith(".gif") || fileName.endsWith(".tiff") || fileName.endsWith(".bmp");
	    }
	    
	   
	    
	    private boolean isSummarizable(File file) {
	        // List of supported file extensions for documents
	        String[] supportedExtensions = {".txt", ".doc", ".docx", ".xlsx", ".pptx", ".pdf", ".rtf"};
	        
	        // List of supported MIME types for images and media files
	        String[] supportedImageTypes = {"image/png", "image/jpeg", "image/gif", "image/bmp", "image/tiff"};
	        String[] supportedAudioTypes = {"audio/mp3", "audio/wav"};
	        String[] supportedVideoTypes = {"video/mp4"};
	        
	        String fileName = file.getName().toLowerCase();
	        String fileType = getFileType(file);  // Get MIME type for media or image files
	        
	        // Check if the file extension matches the document types
	        for (String ext : supportedExtensions) {
	            if (fileName.endsWith(ext)) {
	                return true;
	            }
	        }

	        // Check if the file's MIME type matches the supported image/audio/video types
	        for (String imgType : supportedImageTypes) {
	            if (fileType.equals(imgType)) {
	                return true;
	            }
	        }
	        for (String audioType : supportedAudioTypes) {
	            if (fileType.equals(audioType)) {
	                return true;
	            }
	        }
	        for (String videoType : supportedVideoTypes) {
	            if (fileType.equals(videoType)) {
	                return true;
	            }
	        }

	        // If none of the conditions matched, return false
	        return false;
	    }


	    private String extractFileContent(File file) throws IOException {
	        String fileName = file.getName().toLowerCase();

	        // Handle .txt and .rtf files directly
	        if (fileName.endsWith(".txt") || fileName.endsWith(".rtf")) {
	            return Files.readString(file.toPath());
	        }

	        // Handle .doc and .docx using Apache POI
	        if (fileName.endsWith(".doc") || fileName.endsWith(".docx")) {
	            try (FileInputStream fis = new FileInputStream(file)) {
	                XWPFDocument document = new XWPFDocument(fis);
	                XWPFWordExtractor extractor = new XWPFWordExtractor(document);
	                return extractor.getText();
	            } catch (Exception e) {
	                return "Error extracting content from Word file: " + e.getMessage();
	            }
	        }

	        // Handle .pdf using PDFBox
	        if (fileName.endsWith(".pdf")) {
	            try (PDDocument document = PDDocument.load(file)) {
	                PDFTextStripper stripper = new PDFTextStripper();
	                return stripper.getText(document);
	            } catch (Exception e) {
	                return "Error extracting content from PDF file: " + e.getMessage();
	            }
	        }

	        // Handle other types (e.g., .xlsx, .pptx) as needed
	       /* if (fileName.endsWith(".xlsx")) {
	            try (FileInputStream fis = new FileInputStream(file)) {
	                Workbook workbook = new XSSFWorkbook(fis);
	                Sheet sheet = workbook.getSheetAt(0);
	                StringBuilder sheetContent = new StringBuilder();
	                for (Row row : sheet) {
	                    for (Cell cell : row) {
	                        sheetContent.append(cell.toString()).append("\t");
	                    }
	                    sheetContent.append("\n");
	                }
	                return sheetContent.toString();
	            } catch (Exception e) {
	                return "Error extracting content from Excel file: " + e.getMessage();
	            }
	        }
	        if (fileName.endsWith(".xlsx")) {
	            try (FileInputStream fis = new FileInputStream(file)) {
	                Workbook workbook = new XSSFWorkbook(fis);
	                Sheet sheet = workbook.getSheetAt(0); // Extract content from the first sheet
	                StringBuilder sheetContent = new StringBuilder();

	                for (Row row : sheet) {
	                    for (Cell cell : row) {
	                        switch (cell.getCellType()) {
	                            case STRING:
	                                sheetContent.append(cell.getStringCellValue()).append("\t");
	                                break;
	                            case NUMERIC:
	                                sheetContent.append(cell.getNumericCellValue()).append("\t");
	                                break;
	                            case BOOLEAN:
	                                sheetContent.append(cell.getBooleanCellValue()).append("\t");
	                                break;
	                            default:
	                                sheetContent.append(" ").append("\t");
	                        }
	                    }
	                    sheetContent.append("\n");
	                }

	                workbook.close();
	                return sheetContent.toString();
	            } catch (Exception e) {
	                return "Error extracting content from Excel file: " + e.getMessage();
	            }
	        }*/

	        if (fileName.endsWith(".pptx")) {
	            try (FileInputStream fis = new FileInputStream(file)) {
	                XMLSlideShow ppt = new XMLSlideShow(fis);
	                StringBuilder pptContent = new StringBuilder();
	                for (XSLFSlide slide : ppt.getSlides()) {
	                    for (XSLFShape shape : slide.getShapes()) {
	                        if (shape instanceof XSLFTextShape) {
	                            pptContent.append(((XSLFTextShape) shape).getText()).append("\n");
	                        }
	                    }
	                }
	                return pptContent.toString();
	            } catch (Exception e) {
	                return "Error extracting content from PowerPoint file: " + e.getMessage();
	            }
	        }

	        // Unsupported file types
	        return "Unsupported file type for content extraction.";
	    }
	    
	    
	    
	    
	    
	    
	 
	    
	    
	    
	     private void displayFilePreview(File file) {

	         if (file.isFile() && file.getName().endsWith(".txt")) {
	             try (FileReader fr = new FileReader(file); Scanner scanner = new Scanner(fr)) {
	                 StringBuilder preview = new StringBuilder();
	                 int lineCount = 0;
	                 while (scanner.hasNextLine() && lineCount < 10) {
	                     preview.append(scanner.nextLine()).append("\n");
	                     lineCount++;
	                 }
	                 fileMetadataArea.setText(preview.toString());
	                 
	             } catch (IOException ex) {
	                 fileMetadataArea.setText("Unable to preview file.");
	             }
	         } else {
	             fileMetadataArea.setText("No preview available for this file.");
	         }
	         displayFileMetadata(file);
	     }
	    
	     
	     
	 }