/*Tavoy Gordon - 2102035
Angel Pinnock - 2203595
Ricou Eldemire - 2108884
Antonio Goldson - 2206840*/

package com.java.azure;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

//import com.google.cloud.aiplatform.v1.GenerateContentResponse;
import com.google.cloud.vertexai.VertexAI;
import com.google.cloud.vertexai.api.Part;
import com.google.cloud.vertexai.generativeai.ContentMaker;
import com.google.cloud.vertexai.generativeai.GenerativeModel;
import com.google.cloud.vertexai.generativeai.PartMaker;
import com.google.cloud.vertexai.generativeai.ResponseHandler;
import com.google.cloud.vertexai.api.GenerateContentResponse;




public class GeminiAIAPI {
	   private static final String videoSASUrl= "gs://javafilebrowsercontainer/Lady Gaga-Poker Face.mp4";
	   private static final String audioSASUrl = "https://utechstorageaccount.blob.core.windows.net/utechstoragecontainer?sp=racwl&st=2024-11-23T23:59:08Z&se=2024-11-29T07:59:08Z&sv=2022-11-02&sr=c&sig=4nrkvsLWXKzM0BWSR9EIRFZ5nHqqYbK4kFBV2%2BOipC8%3D";
	
	public static String summarizeContent(String fileType, String filePath, String projectId, String location, String modelName) throws IOException {
		//System.setProperty("GOOGLE_APPLICATION_CREDENTIALS", "/Users/tavoygordon/Downloads/FileBrowserProject.json");
		
		 // Check if the file type is an image
        System.out.println("gemini call "+filePath+"."+fileType);
        
        
        if (fileType.startsWith("image/")) {
        	System.out.println("image");
            try {
                // Convert the image to a Base64-encoded string
                String base64Image = encodeImageToBase64(filePath);
                return multimodalQuery(projectId, location, modelName, base64Image);
            } catch (Exception e) {
                throw new IOException("Error processing image file: " + e.getMessage(), e);
            }
        }
        if (fileType.startsWith("video/")) {
        	System.out.println("video");

            try {
                return multimodalVideoInput(projectId, location, modelName, videoSASUrl);
                		
            } catch (Exception e) {
                throw new IOException("Error processing Video file: " + e.getMessage(), e);
            }
        }
        if (fileType.startsWith("audio/")) {
        	System.out.println("audio");

            try {
                
                return summarizeAudio(projectId, location, modelName, audioSASUrl);
                		
            } catch (Exception e) {
                throw new IOException("Error processing Audio file: " + e.getMessage(), e);
            }
        }



        try (VertexAI vertexAI = new VertexAI(projectId, location)) {
        	
            GenerativeModel model = new GenerativeModel(modelName, vertexAI);
            
            Part part = PartMaker.fromMimeTypeAndData(fileType, filePath);
            

            com.google.cloud.vertexai.api.GenerateContentResponse response = model.generateContent(
                ContentMaker.fromMultiModalData(
                    part,
                    "Summarize the content of the file concisely."
                )
            );
            String output = ResponseHandler.getText(response);  // Or any similar method depending on your library
            System.out.println(output);

            return output;
        } 
	}
	// Multimodal query for image files
    public static String multimodalQuery(String projectId, String location, String modelName, String dataImageBase64) throws Exception {
    	System.out.println("multimodalQuery");
        try (VertexAI vertexAI = new VertexAI(projectId, location)) {
            byte[] imageBytes = Base64.getDecoder().decode(dataImageBase64);

            GenerativeModel model = new GenerativeModel(modelName, vertexAI);
            GenerateContentResponse response = model.generateContent(
                ContentMaker.fromMultiModalData(
                    "What is this image?", // Modify the prompt as needed
                    PartMaker.fromMimeTypeAndData("image/png", imageBytes)
                )
            );

            return ResponseHandler.getText(response);
        }
    }
    
 // Analyzes the given video input.
    public static String multimodalVideoInput(String projectId, String location, String modelName, String videoUrl)
        throws IOException {
      // Initialize client that will be used to send requests.
      // This client only needs to be created once, and can be reused for multiple requests.
      try (VertexAI vertexAI = new VertexAI(projectId, location)) {
       String videoUri =   "https://utechstorageaccount.file.core.windows.net/test1/Lady Gaga-Poker Face.mp4?sp=rcwd&st=2024-11-24T02:02:39Z&se=2024-11-25T02:02:39Z&sv=2022-11-02&sig=O3F9qYsoOFoxS5L3DnU1Ft4bupJHbSNoDTjg7tFrbe0%3D&sr=f";                     //https://utechstorageaccount.blob.core.windows.net/utechstoragecontainer/Lady Gaga-Poker Face.mp4"; //"gs://cloud-samples-data/video/animals.mp4";
    	  //byte[] videoBytes = Base64.getDecoder().decode(videoBase64);

        GenerativeModel model = new GenerativeModel(modelName, vertexAI);
        GenerateContentResponse response = model.generateContent(
            ContentMaker.fromMultiModalData(
                "What is in the video?",
                PartMaker.fromMimeTypeAndData("video/mp4", videoUri)
            ));

        String output = ResponseHandler.getText(response);
        System.out.println(output);
        
        return output; 
      }
    }
    
    // Analyzes the given audio input.
    public static String summarizeAudio(String projectId, String location, String modelName, String audioUrl)
        throws IOException {
      // Initialize client that will be used to send requests. This client only needs
      // to be created once, and can be reused for multiple requests.
      try (VertexAI vertexAI = new VertexAI(projectId, location)) {
        String audioUri = "gs://cloud-samples-data/generative-ai/audio/pixel.mp3";

        GenerativeModel model = new GenerativeModel(modelName, vertexAI);
        GenerateContentResponse response = model.generateContent(
            ContentMaker.fromMultiModalData(
                "Please provide a summary for the audio.\n"
                    + "Provide chapter titles with timestamps, be concise and short, "
                    + "no need to provide chapter summaries.\n"
                    + "Do not make up any information that is not part of the audio "
                    + "and do not be verbose.",
                PartMaker.fromMimeTypeAndData("audio/mp3", audioUrl)
            ));

        String output = ResponseHandler.getText(response);
        System.out.println(output);

        return output;
      }
    }
    
 // Helper method to download or read a video file and encode it as Base64
    private static String downloadAndEncodeVideo(String videoPath) throws IOException {
        System.out.println("downloadAndEncodeVideo");
        
        byte[] videoBytes;
        
        // Check if the path is a URL or a local file
        if (videoPath.startsWith("http://") || videoPath.startsWith("https://")) {
            // If the path is a URL, download the content
            try (InputStream inputStream = new URL(videoPath).openStream()) {
                videoBytes = inputStream.readAllBytes();
            }
        } else {
            // Otherwise, treat it as a local file path
            videoBytes = Files.readAllBytes(Paths.get(videoPath));
        }

        // Encode the video bytes to Base64
        return Base64.getEncoder().encodeToString(videoBytes);
    }

    // Helper method to convert an image file to a Base64-encoded string
    private static String encodeImageToBase64(String filePath) throws IOException {
    	System.out.println("encodeImageBase64");

        byte[] fileContent = Files.readAllBytes(java.nio.file.Paths.get(filePath));
        return Base64.getEncoder().encodeToString(fileContent);
    }
	
}















