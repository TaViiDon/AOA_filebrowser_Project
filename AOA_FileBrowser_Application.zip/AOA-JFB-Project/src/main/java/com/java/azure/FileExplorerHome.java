package com.java.azure;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class FileExplorerHome extends JFrame{
	
	private static final long serialVersionUID = 1L;
	private final JButton cloudButton;
    private final JButton localDriveButton;
    private final AzureBlobWindow azureWindow;
    private String connectionString;
    private String containerName;
    private  AzureBlobStorage azureBlobStorage;  // Azure Blob Storage connection
   


    public FileExplorerHome() {
        setTitle("🏠 File Explorer Home");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        
        
        connectionString = "DefaultEndpointsProtocol=https;AccountName=utechstorageaccount;AccountKey=q11sBckvv/3RpkndOGuNoxqT1i0SKmIUqy3f0mmFAds1bUu2ZuZ9XuqI49nSwn4OU7/FrbMN1h5U+AStNd5fsA==;EndpointSuffix=core.windows.net";
        containerName = "utechstoragecontainer";
        azureWindow = null;
       
        //TODO:
        /*. Passing the AzureBlobWindow in the FileExplorer so that it can show*/
       // azureWindow = new AzureBlobWindow(); 
       azureBlobStorage = new AzureBlobStorage(connectionString, containerName);
       

        
        JLabel selectLabel = new JLabel("Select Resource:");
        selectLabel.setBounds(20, 20, 150, 30);
        add(selectLabel);

        cloudButton = new JButton("︎💭 Cloud Storage");
        cloudButton.setBounds(20, 60, 150, 30);
        add(cloudButton);

        localDriveButton = new JButton("💾 Hard Drive");
        localDriveButton.setBounds(200, 60, 150, 30);
        add(localDriveButton);

        // ActionListener for Cloud Storage
        cloudButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAzureBlobWindow();
            }
        });

        // ActionListener for Local Hard Drive
        localDriveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openLocalDriveWindow();
            }
        });
    }
    
   
	private void openAzureBlobWindow() {
        AzureBlobWindow azureWindow = new AzureBlobWindow(connectionString, containerName);
        azureWindow.setVisible(true);
        
    }

    private void openLocalDriveWindow() {
        LocalDriveExplorer localDriveExplorer = new LocalDriveExplorer();
        localDriveExplorer.setVisible(true);
    }

    public static void main(String[] args) {
    	
        
        FileExplorerHome home = new FileExplorerHome();
        
        home.setVisible(true);
    }
}

// AzureBlobWindow (Stub - Implement functionality as needed)
/*class AzureBlobWindow extends JFrame {
    private static final long serialVersionUID = 1L;

	public AzureBlobWindow() {
        setTitle("Azure Blob Storage Explorer");
        setSize(600, 400);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        // Initialize components for browsing Azure storage here
    }
}*/

// LocalDriveExplorer to show files in local drives
class LocalDriveExplorer extends JFrame {

    private static final long serialVersionUID = 1L;
	private final DefaultTableModel model;
    private final JTable table;

    public LocalDriveExplorer() {
        setTitle("Local Hard Drive");
        setSize(600, 400);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        model = new DefaultTableModel();
        model.addColumn("Drive");
        model.addColumn("Total Space");
        model.addColumn("Free Space");

        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 20, 560, 300);
        add(scrollPane);

        listDrives();
    }
    
    private void listDrives() {
        model.setRowCount(0);

        // Check the system root drives
        File[] roots = File.listRoots();
        addDrivesToTable(roots);

        // Additional check for macOS /Volumes directory
        File volumesDir = new File("/Volumes");
        if (volumesDir.exists() && volumesDir.isDirectory()) {
            File[] volumes = volumesDir.listFiles();
            addDrivesToTable(volumes);
        }
    }
    
    private void addDrivesToTable(File[] drives) {
        if (drives != null) {
            for (File drive : drives) {
                if (drive.exists() && drive.canRead()) {
                    model.addRow(new Object[]{
                        drive.getAbsolutePath(),
                        formatSize(drive.getTotalSpace()),
                        formatSize(drive.getFreeSpace())
                    });
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "No drives found!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
 // Format sizes in GB for readability
    private String formatSize(long size) {
        return size / (1024 * 1024 * 1024) + " GB";
    }

    
    
    
    

}
