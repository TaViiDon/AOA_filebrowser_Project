package com.java.azure;

import java.awt.image.FilteredImageSource;
import java.io.File;

import com.azure.ai.vision.imageanalysis.models.ImageAnalysisOptions;
import com.azure.ai.vision.imageanalysis.ImageAnalysisClient;
import com.azure.ai.vision.imageanalysis.ImageAnalysisClientBuilder;
import com.azure.ai.vision.imageanalysis.ImageAnalysisAsyncClient;


/*public class AzureImageCapture {
	private static final String ENDPOINT = System.getenv("https://azure-java-file-explorer-project.cognitiveservices.azure.com/");
    private static final String KEY = System.getenv("bxZg6JjMdrJpCTWU1Znr0WaC6hwZoPJslXbBICYaBtZrBXnKURHBJQQJ99AKACYeBjFXJ3w3AAAFACOGe3fc");


    public static String summarizeImage(File imageFile) {
        if (ENDPOINT == null || KEY == null) {
            throw new IllegalStateException("Environment variables 'VISION_ENDPOINT' or 'VISION_KEY' are not set.");
        }

        ImageAnalysisAsyncClient client = new ImageAnalysisClientBuilder()
                .endpoint(ENDPOINT)
                .credential(new AzureKeyCredential(KEY))
                .buildAsyncClient();
        

        try {
            var result = client.analyzeImageFromFile(imageFile.toURI().toString());
            return result.getDescription().getCaptions().stream()
                    .findFirst()
                    .map(caption -> caption.getText())
                    .orElse("No summary available.");
        } catch (Exception e) {
            return "Error processing image: " + e.getMessage();
        }
    }
}*/