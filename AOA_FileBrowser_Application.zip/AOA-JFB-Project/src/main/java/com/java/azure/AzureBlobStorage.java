
/*Tavoy Gordon - 2102035
Angel Pinnock - 2203595
Ricou Eldemire - 2108884
Antonio Goldson - 2206840*/

package com.java.azure;

//import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
//import java.util.stream.Collectors;
import java.util.Set;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobClientBuilder;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobContainerClientBuilder;
import com.azure.storage.blob.specialized.BlobClientBase;
import com.azure.storage.blob.models.BlobItem;
import com.azure.storage.blob.models.BlobProperties;
import com.azure.storage.blob.models.BlobRange;
//import com.azure.storage.blob.specialized.BlockBlobClient;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.InputStream;

public class AzureBlobStorage {
	
	private final BlobContainerClient containerClient;
	private List<String> files;//Stores a list of files in the container
    private Set<String>  folders;//Stores a list of folders in the container
    
    private static final Map<String, String> MAGIC_NUMBERS = new HashMap<>();
    static {
        // some basic photo file types
        MAGIC_NUMBERS.put("FFD8FF", "JPEG Image");
        MAGIC_NUMBERS.put("89504E47", "PNG Image");
        MAGIC_NUMBERS.put("47494638", "GIF Image");
        MAGIC_NUMBERS.put("25504446", "PDF Document");
        MAGIC_NUMBERS.put("424D", "BMP Image");
        MAGIC_NUMBERS.put("49492A00", "TIFF Image (little-endian)");
        MAGIC_NUMBERS.put("4D4D002A", "TIFF Image (big-endian)");
  
         // Audio and Video Types
        MAGIC_NUMBERS.put("66747970", "MP4"); // MP4/MOV (ftyp)
        MAGIC_NUMBERS.put("494433", "MP3"); // MP3 (ID3v2)
        MAGIC_NUMBERS.put("FFFB", "MP3"); // MP3 (MPEG Header)
        MAGIC_NUMBERS.put("FFF3", "MP3"); // MP3 (MPEG Header)
        MAGIC_NUMBERS.put("52494646", "WAV"); // WAV/AVI (RIFF)
        MAGIC_NUMBERS.put("41564920", "AVI"); // AVI
        MAGIC_NUMBERS.put("664C6143", "FLAC"); // FLAC (fLaC)
        MAGIC_NUMBERS.put("1A45DFA3", "MKV"); // MKV (EBML)
        MAGIC_NUMBERS.put("494433", "MP3 Audio");
        MAGIC_NUMBERS.put("52494646", "WAV Audio");

        // Basic document types
        //MAGIC_NUMBERS.put("D0CF11E0A1B11AE1", "DOC");
        //MAGIC_NUMBERS.put("504B0304", "DOCX"); 
        MAGIC_NUMBERS.put("D0CF11E0", "Microsoft Office (DOC, XLS, PPT)"); // Compound File Binary Format
        MAGIC_NUMBERS.put("504B0304", "Microsoft Office/ZIP Archive (DOCX, XLSX, PPTX)"); // ZIP-based formats
        MAGIC_NUMBERS.put("0x00000000", "Open Document Format (ODT, ODS, ODP)"); // ODF files (general case)
    }
	
	  // connectionstring and containername from azure blob
    public AzureBlobStorage(String connectionString, String containerName) {
        this.containerClient = new BlobContainerClientBuilder()
                .connectionString(connectionString)
                .containerName(containerName)
                .buildClient();
        
        folders = new  HashSet<>(); 
        files = new ArrayList<>();
    }
    
    //TEST
    /*
    public File downloadBlobToFile(String blobName) throws IOException {
        // Get the BlobClient
        BlobClient blobClient = containerClient.getBlobClient(blobName);

        // Create a temporary file
        File tempFile = File.createTempFile("downloaded-", "-" + blobName);
        tempFile.deleteOnExit();  // Ensure the file is deleted on program exit

        // Download blob content into the temporary file
        try (InputStream blobStream = blobClient.openInputStream();
             FileOutputStream fileOutputStream = new FileOutputStream(tempFile)) {

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = blobStream.read(buffer)) != -1) {
                fileOutputStream.write(buffer, 0, bytesRead);
            }
        }

        return tempFile;  // Return the temporary file with blob contents
    }*/

    
    // Method to get BlobClient for a specific blob
    public BlobClient getBlobClient(String blobName) {
        return containerClient.getBlobClient(blobName);
    }

	// Method to return the container client (so you can interact with the container)
    public BlobContainerClient getContainerClient() {
        return containerClient;
    }
  
    public boolean isConnected() {
        return containerClient.exists();
    }
    
 // Upload a file to a specified folder in Azure Blob Storage
    /*public void uploadFile(String folderName, File file) {
        try {
            String blobName = folderName + "/" + file.getName();
            new BlobClientBuilder()
                .connectionString("DefaultEndpointsProtocol=https;AccountName=utechstorageaccount;AccountKey=q11sBckvv/3RpkndOGuNoxqT1i0SKmIUqy3f0mmFAds1bUu2ZuZ9XuqI49nSwn4OU7/FrbMN1h5U+AStNd5fsA==;EndpointSuffix=core.windows.net")
                .containerName("utechstoragecontainer")
                .blobName(blobName)
                .buildClient()
                .uploadFromFile(file.getAbsolutePath(), true);
            System.out.println("File uploaded to folder: " + folderName);
        } catch (Exception e) {
            System.err.println("Error uploading file: " + e.getMessage());
        }
    }*/
    
    public String uploadFile(String folderName, File file) {
        try {
            String blobName = folderName + "/" + file.getName();
            BlobClient blobClient = new BlobClientBuilder()
                .connectionString("DefaultEndpointsProtocol=https;AccountName=utechstorageaccount;AccountKey=q11sBckvv/3RpkndOGuNoxqT1i0SKmIUqy3f0mmFAds1bUu2ZuZ9XuqI49nSwn4OU7/FrbMN1h5U+AStNd5fsA==;EndpointSuffix=core.windows.net")
                .containerName("utechstoragecontainer")
                .blobName(blobName)
                .buildClient();

            blobClient.uploadFromFile(file.getAbsolutePath(), true);

            // Return the file URL
            String fileUrl = blobClient.getBlobUrl();
            System.out.println("File uploaded successfully to folder: " + folderName);
            return fileUrl;

        } catch (Exception e) {
            System.err.println("Error uploading file: " + e.getMessage());
            return null;
        }
    }
    
    
    //Retrieve all files and folders
   
   // public void getFilesAndDirectories() {

       // for (BlobItem blobItem : containerClient.listBlobs()) {
            //String name = blobItem.getName();
           // String[] myfile;
            
            
            
            // Check if it ends with '/', indicating a folder
           // if (name.contains("/")) {
            	//System.out.println("getFilesADirec IF: "+name);
                //folders.add(name);
            //} else {
            //	System.out.println("getFilesADirec : ELSE "+name);
            	/*
            	myfile = name.split("/");
            	if(myfile.length >1) {
            		name = myfile[myfile.length - 1];
            	}else {
            		name = myfile[0];
            	}*/
            	
                //files.add(name);
           // }
      //  }
   // }

    public void getFilesAndDirectories() {
        retrieveFiles();
        retrieveFolders();
    }
    
    private void retrieveFiles() {
        for (BlobItem blobItem : containerClient.listBlobs()) {
            String name = blobItem.getName();

            if (name.endsWith("/")) {
                // If the blob name ends with '/', it is considered a folder
                //System.out.println("Adding to folders: " + name);
                folders.add(name);

            } else {
                // If no '/', it's a root-level file
                //System.out.println("Adding to root-level files: " + name);
                files.add(name);
            }
        }
    }

    private void retrieveFolders() {
        for (BlobItem blobItem : containerClient.listBlobs()) {
            String name = blobItem.getName();

            if (name.contains("/")) {
                // If the blob name ends with '/', it is considered a folder
                //System.out.println("Adding to folders: " + name);
                //folders.add(name);
                // Extract the folder path up to the first '/'
                String folderPath = name.substring(0, name.indexOf("/") + 1);
                folders.add(folderPath); // Add unique folder path to the set

            }
        }
    }
    
  //Method to retrieve list of files
    public List<String> getFiles(){
    	return files;
    }
    //Method to retrieve list of folders
    public Set<String> getFolders(){
    	return folders;
    }
    
    // Method to list all files and directories in the blob container
    /*
    public List<String> listFilesAndDirectories() {
        List<String> folderNames = new ArrayList<>();
        
        // Loop through all blobs in the container
        for (BlobItem blobItem : containerClient.listBlobs()) {
            String blobName = blobItem.getName();
            
            // Check if it's a "folder" by verifying if it ends with a slash
            if (blobName.endsWith("/")) {
                folderNames.add(blobName);
            }
        }
        
        return folderNames;
    }*/
    

   
    
    
 // Download a folder or file from Azure Blob Storage
   /* public void downloadFile(String folderName) {
        // Implement download logic here, such as listing and downloading blobs in the folder
        System.out.println("Download started for folder/file: " + folderName);
    }*/
    
    public void downloadFileOrFolder(String blobName, String localDirectoryPath) {
        BlobClient blobClient = containerClient.getBlobClient(blobName);

        // Check if it's a folder by checking if there are any blobs prefixed by the blobName
        if (blobClient.exists()) {
            // It's a file, so download directly
            downloadBlob(blobClient, localDirectoryPath);
        } else {
            // It's a folder, so download each file within it
            for (BlobItem blobItem : containerClient.listBlobsByHierarchy(blobName + "/")) {
                BlobClient fileBlobClient = containerClient.getBlobClient(blobItem.getName());
                downloadBlob(fileBlobClient, localDirectoryPath + File.separator + blobItem.getName().substring(blobName.length()));
            }
        }
    }

    private void downloadBlob(BlobClient blobClient, String destinationPath) {

        File localFile = new File(destinationPath);
        localFile.getParentFile().mkdirs();

        try (OutputStream os = new FileOutputStream(localFile)) {
            blobClient.download(os);
        } catch (IOException e) {
            e.printStackTrace();
        }
    
   
}
    
    
    
    
    
 // Convert byte array to hex string
    private static String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            hexString.append(String.format("%02X", b));
        }
        //System.out.println("HexStr "+ hexString.toString()+"\n");
        return hexString.toString();
    }
    
    private static void inspectHeader(byte[] header) {
        // Log actual byte array and hex string for verification
        System.out.println("Header (byte array): " + Arrays.toString(header));
        System.out.println("HexStr: " + bytesToHex(header));
    }
    
}