/*Tavoy Gordon - 2102035
Angel Pinnock - 2203595
Ricou Eldemire - 2108884
Antonio Goldson - 2206840*/


package com.java.azure;


import java.io.File;
import java.util.Stack;

public class NavigationStack {
	
	 private final Stack<String> backStack;
	 private final Stack<String> forwardStack;
	 
	 public NavigationStack() {
	        backStack = new Stack<>();
	        forwardStack = new Stack<>();
	    }
	 
	// Push current directory to back stack and clear forward stack
	 public void pushBack(String directory) {
	        backStack.push(directory);
	        // Clear forward history whenever a new path is added to back
	        forwardStack.clear();
	    }
	 
	 public void navigateTo(String folderPath) {
	        if (!backStack.isEmpty()) {
	            forwardStack.clear();
	        }
	        backStack.push(folderPath);
	    }


	// Move back to the previous directory
	 public String goBack(String currentDirectory) {
	        if (!backStack.isEmpty()) {
	            // Save current directory to forward stack
	            forwardStack.push(currentDirectory);
	            // Move back in history
	            return backStack.pop();
	        }
	        // No back history available
	        return null;
	    }
	
	

	// Move forward to the next directory
	 public String goForward(String currentDirectory) {
	        if (!forwardStack.isEmpty()) {
	            // Save current directory to back stack
	            backStack.push(currentDirectory);
	            // Move forward in history
	            return forwardStack.pop();
	        }
	        // No forward history available
	        return null;
	    }
	 

	// Check if back navigation is possible
	public boolean canGoBack() {
		return !backStack.isEmpty();
	}

	// Check if forward navigation is possible
	public boolean canGoForward() {
		return !forwardStack.isEmpty();
	}
	
	public String getCurrentFolder() {
       return backStack.isEmpty() ? null : backStack.peek();
   }
}