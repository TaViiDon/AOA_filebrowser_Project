package org.filebrowser;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import javax.swing.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.io.*;

public class MicrosoftDocuments {

    // Check if application is available on the system
    public boolean isApplicationAvailable(String appPath) {
        File app = new File(appPath);
        return app.exists();
    }

    // Get OS-specific path to application
    public String getApplicationPath(String appName) {
        String os = System.getProperty("os.name").toLowerCase();
        if (os.contains("win")) {
            switch (appName) {
                case "Word":
                    return "C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE";
                case "Excel":
                    return "C:\\Program Files\\Microsoft Office\\root\\Office16\\EXCEL.EXE";
                case "PowerPoint":
                    return "C:\\Program Files\\Microsoft Office\\root\\Office16\\POWERPNT.EXE";
            }
        }
        return null;
    }

    public void WordDocument(File file) {
        if (isApplicationAvailable(getApplicationPath("Word"))) {
            openInApplication(file, getApplicationPath("Word"));
        } else {
            showDocumentInTextArea(file);
        }
    }

    public void PowerPointDocument(File file) {
        if (isApplicationAvailable(getApplicationPath("PowerPoint"))) {
            openInApplication(file, getApplicationPath("PowerPoint"));
        } else {
            JOptionPane.showMessageDialog(null, "Cannot display PowerPoint files offline.");
        }
    }

    public void ExcelDocument(File file) {
        if (isApplicationAvailable(getApplicationPath("Excel"))) {
            openInApplication(file, getApplicationPath("Excel"));
        } else {
            JOptionPane.showMessageDialog(null, "Cannot display Excel files offline.");
        }
    }

    private void openInApplication(File file, String appPath) {
        try {
            String[] command = {appPath, file.getAbsolutePath()};
            new ProcessBuilder(command).start();
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error opening document in application.");
        }
    }

    public void showDocumentInTextArea(File file) {
        try (FileInputStream fis = new FileInputStream(file)) {
            XWPFDocument document = new XWPFDocument(fis);
            StringBuilder text = new StringBuilder();

            for (XWPFParagraph paragraph : document.getParagraphs()) {
                text.append(paragraph.getText()).append("\n");
            }
            JFrame frame = new JFrame("Document Viewer");
            JTextArea textArea = new JTextArea();
            textArea.setText(text.toString());
            textArea.setLineWrap(true);
            textArea.setWrapStyleWord(true);
            textArea.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(textArea);
            frame.add(scrollPane);
            frame.setSize(800, 600);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setVisible(true);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error displaying document: " + e.getMessage());
        }
    }


    public void textDisplay(File file) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            StringBuilder text = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                text.append(line).append("\n");
            }

            JFrame frame = new JFrame("Text File Viewer");
            JTextArea textArea = new JTextArea();
            textArea.setText(text.toString());
            textArea.setLineWrap(true);
            textArea.setWrapStyleWord(true);
            textArea.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(textArea);
            frame.add(scrollPane);
            frame.setSize(800, 600);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setVisible(true);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error displaying text file: " + e.getMessage());
        }
    }

}
