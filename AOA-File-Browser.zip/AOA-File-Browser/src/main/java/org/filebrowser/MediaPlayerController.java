package org.filebrowser;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.embed.swing.JFXPanel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.util.Duration;

import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;

public class MediaPlayerController {

    @FXML
    private Button btnPlay;

    @FXML
    private Label lblDuration;

    @FXML
    private MediaView mediaView;

    @FXML
    private Slider slider;

    private Media media;
    private MediaPlayer mediaPlayer;

    private boolean isPlayed = false;

    public void openMediaPlayer(File file) {
        JFrame mediaFrame = new JFrame("Media Player");
        JFXPanel jfxPanel = new JFXPanel();
        mediaFrame.add(jfxPanel);
        mediaFrame.setSize(800, 700);
        mediaFrame.setVisible(true);

        //stops the media playback when the window is closing
//        mediaFrame.addWindowListener(new WindowAdapter() {
//            @Override
//            public void windowClosing(WindowEvent e) {
//                if (mediaPlayer != null) {
//                    mediaPlayer.stop();
//                }
//            }
//        });
        mediaFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (mediaPlayer != null) {
                    mediaPlayer.stop();
                }
                Platform.runLater(() -> {
                    if (mediaPlayer != null) {
                        mediaPlayer.dispose();
                    }
                    Platform.exit();
                });
            }
        });

        Platform.runLater(() -> {
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/media-player.fxml"));
                BorderPane mediaPlayerPane = fxmlLoader.load();
                MediaPlayerController mediaPlayerController = fxmlLoader.getController();
                mediaPlayerController.selectMedia(file);
                Scene scene = new Scene(mediaPlayerPane);
                jfxPanel.setScene(scene);

                // Set the media file
                mediaPlayerController.selectMedia(file);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    @FXML
    void btnPlay(MouseEvent event) {
        if (!isPlayed) {
            btnPlay.setText("Pause");
            mediaPlayer.play();
            isPlayed = true;
        } else {
            btnPlay.setText("Play");
            mediaPlayer.pause();
            isPlayed = false;
        }
    }

    @FXML
    void btnStop(MouseEvent event) {
        btnPlay.setText("Play");
        mediaPlayer.stop();
        isPlayed = false;
    }

    @FXML
    public void selectMedia(File selectedFile) {
        if (selectedFile != null && selectedFile.exists()) {
            try {
                // Load media from file
                media = new Media(selectedFile.toURI().toString());
                mediaPlayer = new MediaPlayer(media);

                // Set the media player to the MediaView
                mediaView.setMediaPlayer(mediaPlayer);

                // Update the slider and duration label as media plays
                mediaPlayer.currentTimeProperty().addListener((observable, oldValue, newValue) -> {
                    slider.setValue(newValue.toSeconds());
                    lblDuration.setText("Duration: " + (int) slider.getValue() + " / " + (int) media.getDuration().toSeconds());
                });

                // Configure slider and duration once media is ready
                mediaPlayer.setOnReady(() -> {
                    Duration totalDuration = media.getDuration();
                    slider.setMax(totalDuration.toSeconds());
                    lblDuration.setText("Duration: 00 / " + (int) totalDuration.toSeconds());
                });

                // Wait for the MediaView to be added to the scene
                mediaView.sceneProperty().addListener(new ChangeListener<Scene>() {
                    @Override
                    public void changed(ObservableValue<? extends Scene> observable, Scene oldScene, Scene newScene) {
                        if (newScene != null) {
                            // Responsive layout: adjust MediaView size with scene
                            mediaView.fitWidthProperty().bind(newScene.widthProperty());
                            mediaView.fitHeightProperty().bind(newScene.heightProperty());
                        }
                    }
                });

            } catch (Exception e) {
                System.err.println("Error loading media: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            System.out.println("Invalid file selected.");
        }
    }

    @FXML
    private void sliderPressed(MouseEvent event) {
        mediaPlayer.seek(Duration.seconds(slider.getValue()));
    }
}

