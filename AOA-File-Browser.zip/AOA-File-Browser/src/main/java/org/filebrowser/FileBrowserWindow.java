package org.filebrowser;

import javafx.embed.swing.JFXPanel;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Scanner;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;


public class FileBrowserWindow extends JFrame {

    private static final long serialVersionUID = 1L;
    private NavigationStack navigationStack;
    private JTextArea fileMetadataArea;
    private JList<File> fileList;
    private DefaultListModel<File> fileListModel;
    private JButton backButton;
    private JButton forwardButton;
    private File currentDirectory;

    private JFXPanel jfxPanel;

    public FileBrowserWindow() {
        navigationStack = new NavigationStack();
        setTitle("File Browser");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Initialize components
        backButton = new JButton("Back <--- ");
        forwardButton = new JButton("Forward ---> ");
        fileMetadataArea = new JTextArea();
        fileListModel = new DefaultListModel<>();
        fileList = new JList<>(fileListModel);
        fileList.setLayoutOrientation(JList.VERTICAL);

        //file view
       // fileViewer = new FileViewer(fileMetadataArea);
        CheckFileType checkFileType = new CheckFileType();

        add(new JScrollPane(fileList), BorderLayout.CENTER);
        add(new JScrollPane(fileMetadataArea), BorderLayout.EAST);


        // Disable buttons initially
        backButton.setEnabled(false);
        forwardButton.setEnabled(false);

        // Layout setup
        JPanel navigationPanel = new JPanel();
        navigationPanel.add(backButton);
        navigationPanel.add(forwardButton);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(fileList), new JScrollPane(fileMetadataArea));
        splitPane.setDividerLocation(300);

        add(navigationPanel, BorderLayout.NORTH);
        add(splitPane, BorderLayout.CENTER);

        // Action listeners
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goBack();
            }
        });

        forwardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goForward();
            }
        });

        // Double-click listener on the file list to open folders or preview files
        fileList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    File selectedFile = fileList.getSelectedValue();
                    if (selectedFile != null) {
                        if (selectedFile.isDirectory()) {
                            navigateTo(selectedFile);
                        } else {
                            //checkFileType.checkFileType(selectedFile);
                            //handleFileOpen(selectedFile);
                          //  displayFilePreview(selectedFile);
                            try { CheckFileType.checkFileType(selectedFile); } catch (IOException v) { v.printStackTrace(); }
                        }
                    }
                }
            }
        });

         //Initialize JavaFX panel for media playback

//        jfxPanel = new JFXPanel();
//        add(jfxPanel, BorderLayout.SOUTH);
//        initializeJavaFX();

        // Start browsing in the home directory
        navigateTo(new File(System.getProperty("user.home")));
    }

//    private void initializeJavaFX(File file) {
//        Platform.runLater(() -> {
//            try {
//                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/media-player.fxml"));
//                BorderPane mediaPlayerPane = fxmlLoader.load();
//                MediaPlayerController mediaPlayerController = fxmlLoader.getController();
//                mediaPlayerController.selectMedia(file);
//                Scene scene = new Scene(mediaPlayerPane);
//                jfxPanel.setScene(scene);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        });
//    }


//    private void handleFileOpen(File file) {
//        if (file.isDirectory()) {
//            // If it's a directory, navigate into it. This is important
//            navigateTo(file);
//        } else if (file.isFile()) {
//            if (file.getName().endsWith(".txt")) {
//                fileViewer.displayTextFile(file);
//            } else if (file.getName().endsWith(".pdf")) {
//                fileViewer.displayPDF(file);
//            } else if (file.getName().endsWith(".docx")) {
//                fileViewer.displayWordDoc(file);
//            } else if (file.getName().endsWith(".mp4") || file.getName().endsWith(".mp3")) {
//                //fileViewer.playMedia(file);
////                if (jfxPanel == null) {
////                    jfxPanel = new JFXPanel();
////                    add(jfxPanel, BorderLayout.SOUTH);
////                    revalidate();
////                }
////                initializeJavaFX(file);
//                fileViewer.openMediaPlayer(file);
//            } else {
//                fileMetadataArea.setText("No preview available for this file.");
//            }
//        }
//    }



    private void navigateTo(File directory) {
        if (currentDirectory != null) {
            navigationStack.pushBack(currentDirectory);
        }
        currentDirectory = directory;
        updateFileList(directory);
        updateNavigationButtons();
    }

    private void updateFileList(File directory) {
        fileListModel.clear();
        File[] files = directory.listFiles();
        if (files != null) {
            Arrays.sort(files);
            for (File file : files) {
                fileListModel.addElement(file);
            }
        }
        displayFileMetadata(directory);
    }

    private void goBack() {
        File previousDirectory = navigationStack.goBack(currentDirectory);
        if (previousDirectory != null) {
            currentDirectory = previousDirectory;
            updateFileList(previousDirectory);
        }
        updateNavigationButtons();
    }

    private void goForward() {
        File nextDirectory = navigationStack.goForward(currentDirectory);
        if (nextDirectory != null) {
            currentDirectory = nextDirectory;
            updateFileList(nextDirectory);
        }
        updateNavigationButtons();
    }

    private void updateNavigationButtons() {
        backButton.setEnabled(navigationStack.canGoBack());
        forwardButton.setEnabled(navigationStack.canGoForward());
    }

    // Display metadata such as name, size, type, and last modified date
    private void displayFileMetadata(File file) {
        StringBuilder metadata = new StringBuilder();
        metadata.append("Name: ").append(file.getName()).append("\n");
        metadata.append("Size: ").append(file.length()).append(" bytes\n");
        metadata.append("Type: ").append(file.isDirectory() ? "Directory" : "File").append("\n");
        metadata.append("Last Modified: ").append(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
                .format(file.lastModified())).append("\n");
        fileMetadataArea.setText(metadata.toString());
    }

    // Display file preview (for text files, show the first few lines)
    private void displayFilePreview(File file) {
        if (file.isFile() && file.getName().endsWith(".txt")) {
            try (FileReader fr = new FileReader(file); Scanner scanner = new Scanner(fr)) {
                StringBuilder preview = new StringBuilder();
                int lineCount = 0;
                while (scanner.hasNextLine() && lineCount < 10) {
                    preview.append(scanner.nextLine()).append("\n");
                    lineCount++;
                }
                fileMetadataArea.setText(preview.toString());
            } catch (IOException ex) {
                fileMetadataArea.setText("Unable to preview file.");
            }
        } else {
            fileMetadataArea.setText("No preview available for this file.");
        }
    }


}
