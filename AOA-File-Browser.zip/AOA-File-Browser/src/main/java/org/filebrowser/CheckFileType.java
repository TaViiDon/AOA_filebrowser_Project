package org.filebrowser;


//import com.github.junrar.exception.RarException;
import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.compressors.CompressorException;
import org.apache.tika.Tika;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class CheckFileType {

    private static MediaPlayerController controller = new MediaPlayerController();
    private static MicrosoftDocuments documents = new MicrosoftDocuments();
    private static CompressedFileHandler compressedFileHandler = new CompressedFileHandler();

    public static void checkFileType(File file) throws IOException {
        Tika tika = new Tika();
        Metadata metadata = new Metadata();
        MediaType mediaType;

        try (BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file))) {
            mediaType = tika.getDetector().detect(bis, metadata);
        }

        String mimeType = mediaType.toString();

        switch (mimeType) {
            case "image/jpeg":
            case "image/png":
                handlePNG(file);
                break;
            case "audio/mpeg":
            case "audio/wav":
            case "audio/aac":
                handleAAC(file);
                break;
            case "video/mp4":
            case "video/quicktime":
            case "video/x-flv":
                handleFLV(file);
                break;
            case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
                handleDOCX(file);
                break;
            case "application/vnd.openxmlformats-officedocument.presentationml.presentation":
                handlePPTX(file);
                break;
            case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
                handleXLSX(file);
                break;
            case "text/plain":
                handleTXT(file);
                break;
            case "application/pdf":
                handlePDF(file);
                break;
            case "application/zip":
            case "application/x-tar":
            case "application/gzip":
            case "application/x-bzip2":
            case "application/x-7z-compressed":
                handleCompressedFile(file, mimeType);
                break;
            default:
                if (file.getName().toLowerCase().endsWith(".rar")) {
                    handleRAR(file);
                } else {
                    System.out.println("Unknown file type: " + mimeType);
                }
                break;
        }
    }

    private static void handlePNG(File file) {
        System.out.println("Handling image file: " + file.getName());
        new ImageViewer(file);
    }

    private static void handleAAC(File file) {
        System.out.println("Handling Audio file: " + file.getName());
        controller.openMediaPlayer(file);
    }

    private static void handleFLV(File file) {
        System.out.println("Handling video file: " + file.getName());
        controller.openMediaPlayer(file);
    }

    private static void handleDOCX(File file) {
        System.out.println("Handling DOCX file: " + file.getName());
        documents.WordDocument(file);
    }

    private static void handlePPTX(File file) {
        System.out.println("Handling PPTX file: " + file.getName());
        documents.PowerPointDocument(file);
    }

    private static void handleXLSX(File file) {
        System.out.println("Handling XLSX file: " + file.getName());
        documents.ExcelDocument(file);
    }

    private static void handleTXT(File file) {
        System.out.println("Handling TXT file: " + file.getName());
        documents.textDisplay(file);
    }

    private static void handlePDF(File file) {
        System.out.println("Handling PDF file: " + file.getName());
        new PDFViewer(file);
    }

    private static void handleCompressedFile(File file, String mimeType) {
        System.out.println("Handling compressed file: " + file.getName());
        try {
            compressedFileHandler.extractFile(file, mimeType);
        } catch (IOException | ArchiveException | CompressorException a) {
            a.printStackTrace();
        }
    }

    private static void handleRAR(File file) {
        System.out.println("Handling RAR file: " + file.getName());
        try {
            compressedFileHandler.RARExtract(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
