package org.filebrowser;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class ImageViewer {

    public ImageViewer(File file) {
        showImage(file);
    }

    private void showImage(File file) {
        try {
            Image image = ImageIO.read(file);
            ImageIcon imageIcon = new ImageIcon(image);

            JLabel label = new JLabel(imageIcon);
            JScrollPane scrollPane = new JScrollPane(label);
            scrollPane.setPreferredSize(new Dimension(800, 600));

            JFrame frame = new JFrame("Image Viewer");
            frame.add(scrollPane);
            frame.setSize(800, 600);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setVisible(true);

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error displaying image: " + e.getMessage());
        }
    }
}
