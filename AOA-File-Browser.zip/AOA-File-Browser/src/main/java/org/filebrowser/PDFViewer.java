package org.filebrowser;

import javax.swing.*;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class PDFViewer {
    private JFrame frame;
    private JLabel pdfLabel;
    private JScrollPane scrollPane;
    private PDFRenderer pdfRenderer;
    private PDDocument document;
    private int currentPage = 0;

    public PDFViewer(File file) {
        try {
            PDDocument document = Loader.loadPDF(file);
            pdfRenderer = new PDFRenderer(document);

            frame = new JFrame("PDF Viewer");
            pdfLabel = new JLabel();
            scrollPane = new JScrollPane(pdfLabel);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

            JButton previousButton = new JButton("Previous");
            JButton nextButton = new JButton("Next");
            JPanel buttonPanel = new JPanel();
            buttonPanel.add(previousButton);
            buttonPanel.add(nextButton);

            previousButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (currentPage > 0) {
                        currentPage--;
                        renderPage();
                    }
                }
            });

            nextButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (currentPage < document.getNumberOfPages() - 1) {
                        currentPage++;
                        renderPage();
                    }
                }
            });

            frame.setLayout(new BorderLayout());
            frame.add(scrollPane, BorderLayout.CENTER);
            frame.add(buttonPanel, BorderLayout.SOUTH);
            frame.setSize(600, 800);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setVisible(true);

            renderPage(); // Render the first page

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error displaying PDF: " + e.getMessage());
            close(); // Ensure resources are closed in case of an error
        }
    }

    private void renderPage() {
        try {
            BufferedImage image = pdfRenderer.renderImageWithDPI(currentPage, 150);
            ImageIcon icon = new ImageIcon(image);
            pdfLabel.setIcon(icon);
            pdfLabel.revalidate(); // Refresh the label to show the new image
            pdfLabel.repaint(); // Repaint the label
            scrollPane.revalidate(); // Ensure the scroll pane updates
            scrollPane.repaint(); // Repaint the scroll pane
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error rendering page: " + e.getMessage());
        }
    }

    public void close() {
        try {
            if (document != null) {
                document.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (frame != null) {
            frame.dispose();
        }
    }
}
