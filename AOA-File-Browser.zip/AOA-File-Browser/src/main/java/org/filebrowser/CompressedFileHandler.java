
package org.filebrowser;

import net.sf.sevenzipjbinding.IInArchive;
import net.sf.sevenzipjbinding.SevenZip;
import net.sf.sevenzipjbinding.SevenZipException;
import net.sf.sevenzipjbinding.impl.RandomAccessFileInStream;
import net.sf.sevenzipjbinding.simple.ISimpleInArchive;
import net.sf.sevenzipjbinding.simple.ISimpleInArchiveItem;
//import com.github.junrar.Junrar;
//import com.github.junrar.exception.RarException;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveException;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.compressors.CompressorException;
import org.apache.commons.compress.compressors.CompressorInputStream;
import org.apache.commons.compress.compressors.CompressorStreamFactory;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;

import javax.swing.*;
import java.io.*;

public class CompressedFileHandler {

    // Method to extract compressed files
    public void extractFile(File compressedFile, String mimeType) throws IOException, ArchiveException, CompressorException{
        File outputDir = chooseOutputDirectory();
        if (outputDir != null) {
            try (FileInputStream fis = new FileInputStream(compressedFile);
                 BufferedInputStream bis = new BufferedInputStream(fis)) {

                switch (mimeType) {
                    case "application/gzip":
                    case "application/x-bzip2":
                        try (CompressorInputStream cis = new CompressorStreamFactory().createCompressorInputStream(bis);
                             ArchiveInputStream ais = new ArchiveStreamFactory().createArchiveInputStream(cis)) {
                            extractEntries(ais, outputDir);
                        }
                        break;
                    case "application/zip":
                    case "application/x-tar":
                    case "application/x-7z-compressed":
                        // Handle 7z files separately
                        if (mimeType.equals("application/x-7z-compressed")) {
                            extract7zEntries(compressedFile, outputDir);
                        } else {
                            try (ArchiveInputStream ais = new ArchiveStreamFactory().createArchiveInputStream(bis)) {
                                extractEntries(ais, outputDir);
                            }
                        }
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Unsupported file format for decompression.");
                        break;
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No output directory selected. Extraction cancelled.");
        }
    }

    //junrar test
//    public void RARExtract(File compressedFile) throws IOException, RarException {
//        File outputDir = chooseOutputDirectory();
//        if (outputDir != null) {
//            Junrar.extract(compressedFile, outputDir);
//            JOptionPane.showMessageDialog(null, "RAR extraction complete.");
//        } else {
//            JOptionPane.showMessageDialog(null, "No output directory selected. Extraction cancelled.");
//        }
//    }

    //method to extract rar5
    public void RARExtract(File compressedFile) throws IOException {
        File outputDir = chooseOutputDirectory();
        if (outputDir != null) {
            try (RandomAccessFile randomAccessFile = new RandomAccessFile(compressedFile, "r");
                 IInArchive inArchive = SevenZip.openInArchive(null, new RandomAccessFileInStream(randomAccessFile))) {

                ISimpleInArchive simpleInArchive = inArchive.getSimpleInterface();

                for (ISimpleInArchiveItem item : simpleInArchive.getArchiveItems()) {
                    if (!item.isFolder()) {
                        File outFile = new File(outputDir, item.getPath());
                        outFile.getParentFile().mkdirs(); // Ensure the parent directories are created
                        try (OutputStream out = new FileOutputStream(outFile)) {
                            item.extractSlow(data -> {
                                try {
                                    out.write(data);
                                } catch (IOException e) {
                                    throw new SevenZipException("Error writing file", e);
                                }
                                return data.length; // Return the number of bytes written
                            });
                        }
                    } else {
                        new File(outputDir, item.getPath()).mkdirs(); // Create directories
                    }
                }
                JOptionPane.showMessageDialog(null, "RAR extraction complete.");
            } catch (SevenZipException e) {
                JOptionPane.showMessageDialog(null, "Error occurred during extraction: " + e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(null, "No output directory selected. Extraction cancelled.");
        }
    }




    // extract entries from archiveInputStream
    private void extractEntries(ArchiveInputStream ais, File outputDir) throws IOException {
        ArchiveEntry entry;
        while ((entry = ais.getNextEntry()) != null) {
            File entryDestination = new File(outputDir, entry.getName());
            if (entry.isDirectory()) {
                entryDestination.mkdirs();
            } else {
                entryDestination.getParentFile().mkdirs();
                try (OutputStream out = new FileOutputStream(entryDestination)) {
                    IOUtils.copy(ais, out);
                }
            }
        }
        JOptionPane.showMessageDialog(null, "Extraction complete.");
    }

    //extract entries from 7z
    private void extract7zEntries(File sevenZFile, File outputDir) throws IOException {
        try (SevenZFile sevenZ = new SevenZFile(sevenZFile)) {
            SevenZArchiveEntry entry;
            while ((entry = sevenZ.getNextEntry()) != null) {
                File entryDestination = new File(outputDir, entry.getName());
                if (entry.isDirectory()) {
                    entryDestination.mkdirs();
                } else {
                    entryDestination.getParentFile().mkdirs();
                    try (OutputStream out = new FileOutputStream(entryDestination)) {
                        IOUtils.copy(sevenZ.getInputStream(entry), out);
                    }
                }
            }
        }
        JOptionPane.showMessageDialog(null, "7z extraction complete.");
    }

    //choose the output directory with file chooser dialog
    private File chooseOutputDirectory() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int result = fileChooser.showSaveDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            return fileChooser.getSelectedFile();
        } else {
            return null;
        }
    }
}
