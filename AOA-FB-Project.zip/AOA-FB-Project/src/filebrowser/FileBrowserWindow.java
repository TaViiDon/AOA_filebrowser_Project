package filebrowser;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Scanner;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTree;




public class FileBrowserWindow extends JFrame {
	
	private static final long serialVersionUID = 1L;
    private NavigationStack navigationStack;
    private JTextArea fileMetadataArea;
    private JList<File> fileList;
    private DefaultListModel<File> fileListModel;
    private JButton backButton;
    private JButton forwardButton;
    private File currentDirectory;
    //private JTree fileTree;
   // private JTextArea fileDetails;
   // private JLabel filePreview;
    
    public FileBrowserWindow() {
        navigationStack = new NavigationStack();
        setTitle("File Browser");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Initialize components
        backButton = new JButton("Back <--- ");
        forwardButton = new JButton("Forward ---> ");
        fileMetadataArea = new JTextArea();
        fileListModel = new DefaultListModel<>();
        fileList = new JList<>(fileListModel);
        fileList.setLayoutOrientation(JList.VERTICAL);

        // Disable buttons initially
        backButton.setEnabled(false);
        forwardButton.setEnabled(false);

        // Layout setup
        JPanel navigationPanel = new JPanel();
        navigationPanel.add(backButton);
        navigationPanel.add(forwardButton);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(fileList), new JScrollPane(fileMetadataArea));
        splitPane.setDividerLocation(300);

        add(navigationPanel, BorderLayout.NORTH);
        add(splitPane, BorderLayout.CENTER);

        // Action listeners
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goBack();
            }
        });

        forwardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goForward();
            }
        });

        // Double-click listener on the file list to open folders or preview files
        fileList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    File selectedFile = fileList.getSelectedValue();
                    if (selectedFile != null) {
                        if (selectedFile.isDirectory()) {
                            navigateTo(selectedFile);
                        } else {
                            displayFilePreview(selectedFile);
                        }
                    }
                }
            }
        });

        // Start browsing in the home directory
        navigateTo(new File(System.getProperty("user.home")));
    }

    private void navigateTo(File directory) {
        if (currentDirectory != null) {
            navigationStack.pushBack(currentDirectory);
        }
        currentDirectory = directory;
        updateFileList(directory);
        updateNavigationButtons();
    }

    private void updateFileList(File directory) {
        fileListModel.clear();
        File[] files = directory.listFiles();
        if (files != null) {
            Arrays.sort(files);
            for (File file : files) {
                fileListModel.addElement(file);
            }
        }
        displayFileMetadata(directory);
    }

    private void goBack() {
        File previousDirectory = navigationStack.goBack(currentDirectory);
        if (previousDirectory != null) {
            currentDirectory = previousDirectory;
            updateFileList(previousDirectory);
        }
        updateNavigationButtons();
    }

    private void goForward() {
        File nextDirectory = navigationStack.goForward(currentDirectory);
        if (nextDirectory != null) {
            currentDirectory = nextDirectory;
            updateFileList(nextDirectory);
        }
        updateNavigationButtons();
    }

    private void updateNavigationButtons() {
        backButton.setEnabled(navigationStack.canGoBack());
        forwardButton.setEnabled(navigationStack.canGoForward());
    }

    // Display metadata such as name, size, type, and last modified date
    private void displayFileMetadata(File file) {
        StringBuilder metadata = new StringBuilder();
        metadata.append("Name: ").append(file.getName()).append("\n");
        metadata.append("Size: ").append(file.length()).append(" bytes\n");
        metadata.append("Type: ").append(file.isDirectory() ? "Directory" : "File").append("\n");
        metadata.append("Last Modified: ").append(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
                .format(file.lastModified())).append("\n");
        fileMetadataArea.setText(metadata.toString());
    }

    // Display file preview (for text files, show the first few lines)
    private void displayFilePreview(File file) {
        if (file.isFile() && file.getName().endsWith(".txt")) {
            try (FileReader fr = new FileReader(file); Scanner scanner = new Scanner(fr)) {
                StringBuilder preview = new StringBuilder();
                int lineCount = 0;
                while (scanner.hasNextLine() && lineCount < 10) {
                    preview.append(scanner.nextLine()).append("\n");
                    lineCount++;
                }
                fileMetadataArea.setText(preview.toString());
            } catch (IOException ex) {
                fileMetadataArea.setText("Unable to preview file.");
            }
        } else {
            fileMetadataArea.setText("No preview available for this file.");
        }
    }
    
    
}
