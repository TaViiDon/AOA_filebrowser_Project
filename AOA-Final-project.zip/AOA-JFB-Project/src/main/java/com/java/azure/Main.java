package com.java.azure;

import java.io.IOException;

import javax.swing.SwingUtilities;




public class Main {
	public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
        	// Provide the connection string and container name
            String connectionString = "DefaultEndpointsProtocol=https;AccountName=utechstorageaccount;AccountKey=q11sBckvv/3RpkndOGuNoxqT1i0SKmIUqy3f0mmFAds1bUu2ZuZ9XuqI49nSwn4OU7/FrbMN1h5U+AStNd5fsA==;EndpointSuffix=core.windows.net";
            String containerName = "utechstoragecontainer";
            

       
            AzureBlobWindow filebrowser = new AzureBlobWindow(connectionString, containerName);
            //filebrowser.refreshFileExplorer();
                  filebrowser.setVisible(true);
                  
                  
        });
        
        
    }

}
        
        
        
        
        
        
        
        
        
        /*SwingUtilities.invokeLater(() -> new AzureBlobWindow(connectionString, containerName));
        
        
     

        AzureBlobStorage storage = new AzureBlobStorage(connectionString, containerName);
        
        // implement other functionalities within the azure and java, e.g upload, list, dowload, delete.
        if (storage.isConnected()) {
        	try {
        	//storage.uploadFile("/Users/tavoygordon/Downloads/test.rtf");
        	
        	storage.listFilesAndDirectories();
        	
        	storage.downloadFile("test.rtf", "/Users/tavoygordon/Downloads/test.rtf");
        	
        } catch (IOException e) {
            e.printStackTrace();
        }
    } else {
        System.out.println("Failed to connect to the container.");
    }*/
//}
    
//}

