package com.java.azure;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
//import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
//import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
//import java.util.stream.Collectors;
import java.util.Set;
import java.util.Stack;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
//import javax.swing.JTree;
import javax.swing.SwingUtilities;
//import javax.swing.tree.DefaultMutableTreeNode;
//import javax.swing.tree.DefaultTreeModel;
//import javax.swing.tree.TreePath;

import com.azure.core.http.rest.PagedIterable;
import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
//import com.azure.storage.blob.models.BlobProperties;
import com.azure.storage.blob.models.BlobItem;
import com.azure.storage.blob.models.BlobProperties;
import com.azure.storage.blob.models.BlobRange;
import com.azure.storage.blob.specialized.BlobClientBase;




public class AzureBlobWindow extends JFrame{
	
	private static final long serialVersionUID = 1L;
	private final NavigationStack navigationStack;
    private final JTextArea fileMetadataArea;
    private JList<File> fileList;
    private final DefaultListModel<File> fileListModel;
    private final JButton backButton;
    private final JButton forwardButton;
    private final JTextField searchField;
    private final BlobContainerClient containerClient;
    private AzureBlobStorage azureBlobStorage;
    private JList<String> folderList;
    private DefaultListModel<String> folderListModel;
    private JScrollPane rightScrollPane;
    private JScrollPane leftScrollPane;
	private JPanel fileListPanel;
	private JPanel fileMetadataPanel; 
	private String folderNameSelected;
	private List<String> files;//Stores a list of files in the container
    private Set<String>  folders;//Stores a list of folders in the container
    private FolderCheckAndCreate folderChecker;
    private long sizeLimit = 10000000L;//10 MB Size limit for the folder 
    private String localPath = "/Users/tavoygordon/temp"; 
    private String folderPath = "/Users/tavoygordon/temp"; 
    private String currentDirectory;
    String storageAccountUrl;
    String containerNameFixed;
    private Stack<File> forwardStack;// Stack to track forward navigation 
	    
    
	    // Constructor to initialize Azure Blob connection and GUI components
	    public AzureBlobWindow(String connectionString, String containerName) {
	    	
	    	
	    	// Set up Azure Blob Storage
	        BlobServiceClient serviceClient = new BlobServiceClientBuilder().connectionString(connectionString).buildClient();
	        containerClient = serviceClient.getBlobContainerClient(containerName);
	    	  
	    	 navigationStack = new NavigationStack();
	    	 forwardStack = new Stack<>();
	    	 
	         setTitle("File Explorer");
	         setSize(800, 600);
	         setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	         setLayout(new BorderLayout());
	       //setupMainFrame();
	        

	         currentDirectory = "";
	         
	         // Initialize components
	         backButton = new JButton("Back <--- ");
	         forwardButton = new JButton("Forward ---> ");
	         fileMetadataArea = new JTextArea();
	         fileListModel = new DefaultListModel<>();
	         fileList = new JList<>(fileListModel);
	         fileList.setLayoutOrientation(JList.VERTICAL);
	         azureBlobStorage = new AzureBlobStorage(connectionString,containerName);
	         folderNameSelected = containerName;

	         folders = new HashSet<>();
	         files = new ArrayList<>();
	         
	         FolderCheckAndCreate folderChecker = new FolderCheckAndCreate();

	         
	         
	         searchField = new JTextField(20);
	         searchField.addActionListener(e -> {
	             String query = searchField.getText(); // Get the text from the search field
	             //String resultMessage = searchFiles(query); // Call the searchFiles method with the query

	             // Display the result message to the user
	            // JOptionPane.showMessageDialog(this, resultMessage, "Search Result", JOptionPane.INFORMATION_MESSAGE);
	         });
	         
	         


	         // Disable buttons initially
	         backButton.setEnabled(true);
	         forwardButton.setEnabled(true);

	         // Layout setup
	         JPanel navigationPanel = new JPanel();
	         navigationPanel.add(backButton);
	         navigationPanel.add(forwardButton);
	         navigationPanel.add(searchField);
	         
	      // Assuming splitPane is already created as in your code
	         leftScrollPane = new JScrollPane(fileList); // Get the left (first) component
	         //fileListPanel = (JPanel) leftScrollPane.getViewport().getView(); // Get the panel inside the scroll pane
	         
	         rightScrollPane = new JScrollPane(fileMetadataArea); // Get the left (first) component
	         //fileMetadataPanel = (JPanel) leftScrollPane.getViewport().getView(); // Get the panel inside the scroll pane
	         
	         JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftScrollPane,rightScrollPane );
	         splitPane.setDividerLocation(300);

	         add(navigationPanel, BorderLayout.NORTH);
	         add(splitPane, BorderLayout.CENTER);
	         
	         String storageAccountUrl = "https://utechstorageaccount.blob.core.windows.net/";
	         String containerNameFixed = "utechstoragecontainer";
	         
	         // Right-click popup menu for creating a folder
	         //JPopupMenu popupMenu = new JPopupMenu();
	         //JMenuItem createFolderItem = new JMenuItem("Create Folder");
	         //popupMenu.add(createFolderItem);
	        // createFolderItem.addActionListener(e -> createFolder());
	         
	         
	      // Back Button Action Listener
	          backButton.addActionListener((ActionEvent e) -> {
	             goBack();
	         });

	         forwardButton.addActionListener((ActionEvent e) -> {
	             goForward();
	         });

	       
	         
	         
	         // Add mouse listener for right-click popup on fileList
	         fileList.addMouseListener(new MouseAdapter() {
	             @Override
	             public void mousePressed(MouseEvent e) {
	                 if (SwingUtilities.isRightMouseButton(e)) {
	                	//popupMenu.show(e.getComponent(), e.getX(), e.getY());
	                	 
	                	 File selectedFile = fileList.getSelectedValue();
	                	 
	                	 if(selectedFile != null) {
	                		 
	                		// Get the folder name
	 	         	        String folderName = selectedFile.toString();
	 	         	      
	 	         	        
	 	                	 //System.out.println("Right click listener is directory "+selectedFile.isDirectory()+" "+selectedFile.toString()+" isNull "+(selectedFile != null));
	 	                	 
	 	         	        //Add a slash to the end and check if the string is in the folder list which means it is a folder and not a file
	 	         	        if(folders.contains(folderName+"/")) {
	 	                			 showContextMenu(e,folderNameSelected);
	 	                		 
	 	                	 }
	                	 }
	                	 
	                 }
	             }
	         });
	         //left-click
	         fileList.addMouseListener(new MouseAdapter() {
	        	    @Override
	        	    public void mouseClicked(MouseEvent e) {
	        	        if (SwingUtilities.isLeftMouseButton(e)) {
	        	        	//refreshFileExplorer();
	        	        	
	        	            // Get the index of the clicked item
	        	            int index = fileList.locationToIndex(e.getPoint());

	        	            // Check if the index is valid (non-negative) and get the selected item
	        	            if (index >= 0) {
	        	                Object selectedItem = fileList.getModel().getElementAt(index);
	        	                folderNameSelected=selectedItem.toString();
	        	                
	        	             /*   
	        	                File selectedFile = fileList.getSelectedValue();
	   	                	 
	   	                	 if (selectedFile != null) {
	   	                		displayFilePreview(selectedFile);
	   	                	  }*/
	        	            }
	        	        }
	        	    }
	        	});
	         
	         //Double-click listener on the file list to open folders or preview files
	         
	         
	         
	         fileList.addMouseListener(new MouseAdapter() {
	             @Override
	             public void mouseClicked(MouseEvent e) {
	                 if (e.getClickCount() == 2) {
	                	 
	                     
	                	 File selectedFile = fileList.getSelectedValue();
	                	 
	                	 if (selectedFile != null) {
	                    	 
	                    	 //for(String folderName:files) {
	                    	//	 System.out.println(folderName);
	                    	 //}
	                    	 
	                    	 
	                         if (folders.contains(selectedFile.toString()+"/")) {//selectedFile.isDirectory()
	                            // navigateTo(selectedFile);
	                        	 //System.out.println("Double click IF IF " + selectedFile.toString());
	                        	
	                        	 listFolderContents(selectedFile.toString());
	                        	System.out.println(selectedFile.toString());
	                         } 
	                         else {
	                        	 //TODO: Update this method to handle files
	                        	 //selectedFile = fileList.getE
	                        	 
	                        	 System.out.println("Double click IF ELSE");
	                        	 
	                        	 String blobName = files.get(fileList.getSelectedIndex());
	                	         
	                	         //String blobUrl = storageAccountUrl + containerNameFixed + "/" + blobName;
	                        	 
	                        	 BlobClientBase blobClient = containerClient.getBlobClient(blobName).getBlockBlobClient();
	                        	 
	                        	// Load the blob into memory
	                             try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
	                                 blobClient.download(outputStream);
	                                 byte[] blobBytes = outputStream.toByteArray();

	                                 // Create a temporary file in memory
	                                 selectedFile = File.createTempFile(getFileName(blobName), "."+getFileHeader(blobClient));
	                                 
	                                 System.out.println("File Type: "+getFileHeader(blobClient));
	                                 selectedFile = File.createTempFile(getFileName(blobName), "."+getFileHeader(blobClient));
	                                 
	                                 Files.write(selectedFile.toPath(), blobBytes);

	                                 // tempFile now holds the blob data
	                                 System.out.println("Loaded blob into in-memory file: " + selectedFile.getAbsolutePath());

	                                 // Delete the temporary file on exit if necessary
	                                 selectedFile.deleteOnExit();
	                             } catch (IOException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
	                        	 
	                             //Check if file exist locally	                             
	                             checkAndHandleFile(containerClient, blobName);

	                             
	                          // Simulating double-click action
	                           openFileOnDoubleClick(selectedFile);
	                             
	                        	 //selectedFile = new File(files.get(fileList.getSelectedIndex()));
	                        	 //selectedFile = new File(blobClient.);
	                        	 
	                        	 //System.out.println("IsFile: "+selectedFile.isFile()+" Exists: "+selectedFile.exists());
	                             displayFilePreview(selectedFile);
	                         }
	                     }
	                 }
	             }
	         });
	         
	         //Call method to check folder
	         folderChecker.CheckAndCreateFolder();
	         refreshFileExplorer();
	         setVisible(true);
	         
	         
	     }
	    
	    private void goForward() {
			
			
		}
		// Method to navigate to a specific "directory" in the Azure container
	    private void navigateTo(String directory) {
	        if (currentDirectory != null) {
	        	File next = new File(directory);
	            navigationStack.goBack(next); // Save current directory for back navigation
	        }

	        currentDirectory = directory; // Set the new directory
	        updateFileList(directory); // Update the displayed file list
	        updateNavigationButtons(); // Update navigation button states
	    }

	    // Method to update the file list based on the currentDirectory
	    private void updateFileList(String directory) {
	        // Use Azure APIs to list blobs within the "directory"
	        PagedIterable<BlobItem> blobs = containerClient.listBlobsByHierarchy(directory + "/");

	        List<String> fileList = new ArrayList<>();
	        for (BlobItem blob : blobs) {
	            String blobName = blob.getName();
	            if (blobName.startsWith(directory) && !blobName.equals(directory)) {
	                fileList.add(blobName.substring(directory.length())); // Remove parent directory prefix
	            }
	        }

	        // Update GUI component (e.g., JList or JTable) with the new file list
	        updateGUIFileList(fileList);
	    }

	    // Dummy method to update the GUI component
	    private void updateGUIFileList(List<String> fileList) {
	        System.out.println("Updating GUI with files: " + fileList);
	        // Implement logic to populate your file list UI
	    }

	    // Method to handle back navigation
	    private void goBack() {
	        if (!navigationStack.canGoBack()) {
	        	File next = new File(currentDirectory);
	            navigationStack.pushBack(next);
	            updateFileList(currentDirectory);
	            updateNavigationButtons();
	        }
	    }
	    
	    /*
	    private void goForward() {
	        if (!forwardStack.isEmpty()) {
	            // Push the current directory to the back stack
	            navigationStack.pushForward(currentDirectory);

	            // Update the current directory from the forward stack
	            currentDirectory = forwardStack.pop();

	            // Update the file list and navigation buttons
	            updateFileList(currentDirectory);
	            updateNavigationButtons();
	        } else {
	            System.out.println("No forward history available.");
	        }
	    }
	    */
	    /*
	    // Method to update navigation button states
	    private void updateNavigationButtons() {
	        System.out.println("Back button state: " + !navigationStack.canGoBack());
	        // Implement logic to enable/disable back/forward buttons
	    }*/
	    
	    private void updateNavigationButtons() {
	         backButton.setEnabled(navigationStack.canGoBack());
	         forwardButton.setEnabled(navigationStack.canGoForward());
	     }
	    

	

	

    				//Divide and Conquer method (Analysis of Algorithm Category) 

    	    public void checkFilesDivideAndConquer(BlobContainerClient containerClient, List<String> blobNames) {
    	        if (blobNames == null || blobNames.isEmpty()) {
    	            return; // Base case: empty list, nothing to process
    	        }

    	        // Base case: If there's only one file, process it
    	        if (blobNames.size() == 1) {
    	            checkAndHandleFile(containerClient, blobNames.get(0));
    	            return;
    	        }

    	        // Divide the list into two halves
    	        int mid = blobNames.size() / 2;
    	        List<String> left = blobNames.subList(0, mid);
    	        List<String> right = blobNames.subList(mid, blobNames.size());

    	        // Conquer: Process each half recursively
    	        checkFilesDivideAndConquer(containerClient, left);
    	        checkFilesDivideAndConquer(containerClient, right);
    	    }

    	    /*private void checkAndHandleFile(BlobContainerClient containerClient, String blobName) {
    	        try {
    	            File localFile = new File(localPath, getFileName(blobName));

    	            // Check if the file exists locally
    	            if (localFile.exists()) {
    	                System.out.println("File exists locally: " + localFile.getAbsolutePath());
    	                openFileOnDoubleClick(localFile);
    	            } else {
    	                System.out.println("File does not exist locally. Downloading from Azure Blob Storage...");
    	                downloadAndOpenFile(containerClient, blobName);
    	            }
    	        } catch (IOException e) {
    	            e.printStackTrace();
    	        }
    	    }*/
    	    private void checkAndHandleFile(BlobContainerClient containerClient, String blobName) {
    	        try {
    	            // Ensure the directory exists
    	            File folder = new File(localPath);
    	            if (!folder.exists()) {
    	                folder.mkdirs();
    	            }

    	            // Check if the file exists in the local directory
    	            File localFile = new File(folder, getFileName(blobName));
    	            if (localFile.exists()) {
    	                System.out.println("File exists locally: " + localFile.getAbsolutePath());
    	                //openFileOnDoubleClick(localFile);
    	            } else {
    	                System.out.println("File does not exist locally. Downloading from Azure Blob Storage...");
    	                downloadAndOpenFile(containerClient, blobName);
    	            }
    	            
    	         // After processing the file, check folder size
    	            checkAndEnforceSizeLimit(new File(localPath));
    	            
    	        } catch (IOException e) {
    	            e.printStackTrace();
    	        }
    	    }

    	    /*private void downloadAndOpenFile(BlobContainerClient containerClient, String blobName) throws IOException {
    	        BlobClientBase blobClient = containerClient.getBlobClient(blobName).getBlockBlobClient();

    	        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
    	            // Download the blob
    	            blobClient.download(outputStream);
    	            byte[] blobBytes = outputStream.toByteArray();

    	            // Create a temporary file locally
    	            File tempFile = File.createTempFile(getFileName(blobName), "." + getFileHeader(blobClient));
    	            Files.write(tempFile.toPath(), blobBytes);

    	            System.out.println("Downloaded and created file: " + tempFile.getAbsolutePath());

    	            // Delete the temporary file on exit
    	            tempFile.deleteOnExit();

    	            // Open the file
    	            openFileOnDoubleClick(tempFile);
    	        }
    	    }*/
    	    
    	    private void downloadAndOpenFile(BlobContainerClient containerClient, String blobName) throws IOException {
    	        BlobClientBase blobClient = containerClient.getBlobClient(blobName).getBlockBlobClient();

    	        // Download blob
    	        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
    	            blobClient.download(outputStream);
    	            byte[] blobBytes = outputStream.toByteArray();

    	            // Ensure the directory exists
    	            File folder = new File(localPath);
    	            if (!folder.exists()) {
    	                folder.mkdirs();
    	            }

    	            // Create the file in the local directory
    	            File downloadedFile = new File(folder, getFileName(blobName));
    	            Files.write(downloadedFile.toPath(), blobBytes);

    	            System.out.println("Downloaded and created file: " + downloadedFile.getAbsolutePath());

    	            // Open the file
    	            //openFileOnDoubleClick(downloadedFile);
    	        }
    	    }
    	    
    	    private void checkAndEnforceSizeLimit(File folder) {
    	        long totalSize = calculateTotalSize(folder);
    	        if (totalSize > sizeLimit) {
    	            System.out.println("Total size exceeds limit! Managing folder contents...");
    	            // Perform deletion to free up space
    	            deleteFolderContents(folder);
    	        } else {
    	            System.out.println("Total size is within the limit.");
    	        }
    	    }

    	    // Calculate the total size of the folder contents
    	    private long calculateTotalSize(File folder) {
    	        long totalSize = 0;
    	        if (folder.isDirectory()) {
    	            for (File file : folder.listFiles()) {
    	                totalSize += file.length();
    	            }
    	        }
    	        return totalSize;
    	    }

    	    // Delete files in the folder if size exceeds the limit
    	    private void deleteFolderContents(File folder) {
    	        if (folder.isDirectory()) {
    	            for (File file : folder.listFiles()) {
    	                if (file.isDirectory()) {
    	                    deleteFolderContents(file); // Recursive delete for subdirectories
    	                }
    	                System.out.println("Deleting file: " + file.getAbsolutePath());
    	                file.delete(); // Delete the file
    	            }
    	        }
    	    }
    	    

    	    private boolean isFolderEmpty(File folder) {
    	        if (folder.exists() && folder.isDirectory()) {
    	            File[] files = folder.listFiles();
    	            return files == null || files.length == 0;
    	        }
    	        return true;
    	    }
    	    
     

	    private void listFolderContents(String folderName) {
	        // Clear the current list model
	        //files.clear();
	        //folders.clear();
	    	fileListModel.clear();
	    	
	    	//System.out.println("List folders");
	    	/*
	    	azureBlobStorage.getFilesAndDirectories();
	        
	        files = azureBlobStorage.getFiles();
	        folders = azureBlobStorage.getFolders();*/
	    	String[] myfile;
	    	
	    	

	        // List all blobs inside the selected folder
	        for (String folder: folders) {
	    	//BlobClientBase blobItem = this.containerClient.getBlobClient(folderName).getPageBlobClient();
	    	
	            //String itemName = blobItem.getBlobName();
	            //System.out.println("Folders "+folder+" foldername "+folderName);
	            
	         // Create a File object for each file name
	            File file = new File(folder);
	            
	            /*
	            myfile = folder.split("/");
	        	if(myfile.length >1) {
	        		fileName = myfile[myfile.length - 1];
	        		
	        		if (name.contains("/")) {
	                    // If the blob name ends with '/', it is considered a folder
	                    // Extract the folder path up to the first '/'
	                    String folderPath = name.substring(0, name.indexOf("/") + 1);
	                    folders.add(folderPath); // Add unique folder path to the set

	                }
	        	}else {
	        		fileName = myfile[0];
	        	}*/
	        	
	            if (folder.contains(folderName)) {  // It's a sub-folder
	            	//System.out.println("IF");
	                
	            	fileListModel.addElement(file);
	                break;
	            }
	        }
	        for (String fileHolder: files) {
		    	//BlobClientBase blobItem = this.containerClient.getBlobClient(folderName).getPageBlobClient();
		    	
		            //String itemName = blobItem.getBlobName();
		            //System.out.println("Folders "+folder);
		            
		            
		            if (fileHolder.contains(folderName)) {  // It's a sub-folder
		            	
		            	
			            
			         // Extract the filename using substring and lastIndexOf
			            String filename = fileHolder.substring(fileHolder.lastIndexOf("/") + 1);
			         
			            // Create a File object for each file name
			            File file = new File(filename);
			            
		                fileListModel.addElement(file);
		            }
		        }
	    }
	    
	    private void showContextMenu(MouseEvent e, String folderName) {
	    	//folderNameSelected=folderName;
	    	//System.out.println(folderNameSelected);
	        // Create popup menu
	        JPopupMenu contextMenu = new JPopupMenu();

	        // "Create Folder" menu item
	        JMenuItem createFolderItem = new JMenuItem("Create Folder");
	        createFolderItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent event) {
	            	createFolder();  // Call create folder method
	            }
	        });
	        contextMenu.add(createFolderItem);

	        // "Upload File" menu item
	        JMenuItem uploadFileItem = new JMenuItem("Upload File");
	        uploadFileItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent event) {
	                uploadFileToFolder(folderName);  // Call upload file method
	            }
	        });
	        contextMenu.add(uploadFileItem);

	        // "Download Folder/File" menu item
	        JMenuItem downloadItem = new JMenuItem("Download Folder/File");
	        downloadItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent event) {
	                downloadFolderOrFile(folderName);  // Call download method
	            }
	        });
	        contextMenu.add(downloadItem);

	        // Show popup menu at the mouse click location
	        contextMenu.show(e.getComponent(), e.getX(), e.getY());
	    }
	    
	    
	    // Default folder method to check and create folder on local machine to store files
	    public class FolderCheckAndCreate {

	        public void CheckAndCreateFolder() {
	        	//path to downlaod folder
	            String folderPath = "/Users/tavoygordon/temp"; 
	            File folder = new File(folderPath);

	            if (!folder.exists()) {
	                if (folder.mkdirs()) {
	                    System.out.println("Folder created: " + folderPath);
	                } else {
	                    System.out.println("Failed to create folder: " + folderPath);
	                }
	            } else {
	                System.out.println("Folder already exists: " + folderPath);
	            }
	        }

	        
	    }
	    
	    //TEST
	   /* public void displayFileFromBlob(String blobName) {
	        try {
	            // Download the blob to a temporary file
	            File file = azureBlobStorage.downloadBlobToFile(blobName);

	            // Now you can use FileInputStream to read the file
	            try (FileInputStream fileInputStream = new FileInputStream(file)) {
	                // Process the file content as needed
	                System.out.println("File content retrieved successfully.");
	            }

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }*/
	    // Function to read the first N bytes of a blob
	    private static byte[] readBlobHeader(BlobClientBase blobClient, int length) throws IOException {
	    	// Get blob properties to determine its actual size
	        BlobProperties properties = blobClient.getProperties();
	        long blobSize = properties.getBlobSize();

	        // Adjust the length if the blob is smaller than the requested range
	        int bytesToRead = (int) Math.min(length, blobSize);
	        BlobRange range = new BlobRange(0, (long) bytesToRead); // Specify range: start 0, length `bytesToRead`

	        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	        blobClient.downloadStreamWithResponse(outputStream, range, null, null, false, null, null);
	        //System.out.println("Header "+outputStream.toByteArray().toString());
	        return outputStream.toByteArray();
	    }

	    // Convert byte array to hex string
	    private static String bytesToHex(byte[] bytes) {
	        StringBuilder hexString = new StringBuilder();
	        for (byte b : bytes) {
	            hexString.append(String.format("%02X", b));
	        }
	        //System.out.println("HexStr "+ hexString.toString()+"\n");
	        return hexString.toString();
	    }
	    
	    public String getFileHeader(BlobClientBase blobClient) {
	    	
            
            //BlobClientBase blobClient = containerClient.getBlobClient(blobName).getBlockBlobClient();
            
	    	String fileType = "Unknown format";
	    	
	 

	            try {
	                // Read the first 8 bytes (adjust based on the longest magic number)
	                byte[] header = readBlobHeader(blobClient, 8);
	                String hexMagicNumber = bytesToHex(header);
	                
	                if (hexMagicNumber.startsWith("504B0304")) {
	                    // Likely a ZIP-based format (DOCX, XLSX, PPTX, or other)
	                    // Download a larger header to inspect for folder structure
	                    byte[] extendedHeader = readBlobHeader(blobClient, 2048);
	                    String extendedHeaderStr = new String(extendedHeader);

	                    if (extendedHeaderStr.contains("word/")) {
	                        return "DOCX";
	                    } else if (extendedHeaderStr.contains("xl/")) {
	                        return "XLSX";
	                    } else if (extendedHeaderStr.contains("ppt/")) {
	                        return "PPTX";
	                    } else {
	                        return "ZIP";
	                    }
	                }

	                // Check for PDF format
	                if (hexMagicNumber.startsWith("255044")) {
	                    return "PDF";
	                }

	                // Check for legacy Office formats (e.g., DOC, XLS, PPT)
	                if (hexMagicNumber.startsWith("D0CF11E0")) {
	                    return "Microsoft Office Binary (DOC, XLS, PPT)";
	                    //"Microsoft Office Binary (DOC, XLS, PPT)"
	                }
	                
	             // Search specifically for the "66747970" (ftyp) signature within the first 64 bytes
	                 if (hexMagicNumber.contains("66747970")) {
	                     return "MP4";
	                 }
	                

	                // Check magic number against known types
	                //fileType = MAGIC_NUMBERS.getOrDefault(hexMagicNumber, "Unknown format");
	                //TODO To remove
	                System.out.println("File: " + blobClient.getBlobName() + " Type: " + fileType);
	                //inspectHeader(header);

	            } catch (IOException e) {
	                System.out.println("Failed to read blob header for file: " + blobClient.getBlobName());
	                e.printStackTrace();
	            }
	        
	    	return fileType;
	    }
	    
	
	    public void openFileOnDoubleClick(File file) {
	        // Check if the file exists
	        if (file.exists() && file.isFile()) {
	            // Get the file type
	            String fileType = "";
	            
				try {
					fileType = getFileType(file);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

	            try {
	                // Use Desktop to open the file if supported
	                if (Desktop.isDesktopSupported()) {
	                    Desktop desktop = Desktop.getDesktop();
	                    
	                    if (desktop.isSupported(Desktop.Action.OPEN)) {
	                        System.out.println("Opening file with default application for type: " + fileType);
	                        desktop.open(file);
	                    } else {
	                        System.out.println("Open action is not supported on this platform.");
	                    }
	                } else {
	                    System.out.println("Desktop API is not supported on this platform.");
	                }
	            } catch (IOException e) {
	                System.out.println("Error opening the file: " + e.getMessage());
	            }
	        } else {
	            System.out.println("File does not exist or is not a file.");
	        }
	    }
	 // Method to update the file list
	    public void updateFileList(List<String> files) {
	        fileListPanel.removeAll(); // Clear current list of files

	        // Add each file as a label or component to the panel
	        for (String fileName : files) {
	            JLabel fileLabel = new JLabel(fileName);
	            fileListPanel.add(fileLabel);
	        }

	        // Refresh the panel to display new content
	        fileListPanel.revalidate();
	        fileListPanel.repaint();
	    }
	    
	    private void loadFolders() {
	        // Clear the current list
	    	folders.clear();
	        folderListModel.clear();

	        // Fetch folders from Azure Blob Storage
	        folders = azureBlobStorage.getFolders();

	        // Add each folder to the GUI list model
	        for (String folder : folders) {
	            folderListModel.addElement(folder);
	        }
	    }
	    
	    
	    private String getFileName(String fileName) {
	    	
	    	String[] myfile;
	    	
	    	myfile = fileName.split("/");
        	if(myfile.length >1) {
        		fileName = myfile[myfile.length - 1];
        	}else {
        		fileName = myfile[0];
        	}
	    	
	    	return fileName;
	    }
	    
	    public void refreshFileExplorer() {
	    	//System.out.println("refreshFileExplorer");
	    	
	    	//Clear the files and folders list in order to prevent duplicates when you refresh file explorer
	    	files.clear();
	    	folders.clear();
	    	
	        fileListModel.clear(); // Clear existing items

	        // Fetch files and folders from Azure Blob Storage
	        azureBlobStorage.getFilesAndDirectories();
	        
	        files = azureBlobStorage.getFiles();
	        folders = azureBlobStorage.getFolders();
	        
	        String[] myfile;
	        
	        for (String fileName : files) {
	        	//System.out.println("Contains folders "+fileListModel.contains(fileName)+" "+fileName);
	                
	            if(!(fileListModel.contains(fileName))){
	            	myfile = fileName.split("/");
	            	if(myfile.length >1) {
	            		fileName = myfile[myfile.length - 1];
	            	}else {
	            		fileName = myfile[0];
	            	}
	            	
	            	// Create a File object for each file name
		            File file = new File(fileName);
		            
		            // Add the File object to the model
		            fileListModel.addElement(file);
	            }
	            
	            //System.out.println("FName "+ fileName);
	            
            	
	        }
	        for (String folderName : folders) {
	        	//System.out.println("Contains folders "+fileListModel.contains(folderName)+" "+folderName);
	        	// Create a File object for each file name
	        	if(!(fileListModel.contains(folderName))){
	        		File file = new File(folderName);
		            
		            
		            // Add the File object to the model
		            fileListModel.addElement(file);
	        	}
	        	
	        }
	        
	        //updateFileList(filesAndDirs);
	    }
	    
	      // Method to create a new folder
	         private void createFolder() {
	             String folderName = JOptionPane.showInputDialog(this, "Enter Folder Name:", "Create Folder", JOptionPane.PLAIN_MESSAGE);

	             if (folderName != null && !folderName.trim().isEmpty()) {
	                 // Add a "/" to the end of folder name to signify it's a folder
	                 String blobFolderName = folderName + "/";

	                 // Create a blob client for the folder
	                 BlobClient blobClient = containerClient.getBlobClient(blobFolderName);

	                 // Upload empty content to create the "folder"
	                 blobClient.upload(new ByteArrayInputStream(new byte[0]), 0);
	                 refreshFileExplorer();

	                 JOptionPane.showMessageDialog(this, "Folder created: " + folderName, "Folder Creation", JOptionPane.INFORMATION_MESSAGE);
	             } else {
	                 JOptionPane.showMessageDialog(this, "Folder name cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
	             }
	         

	         // Additional helper methods (e.g., for file metadata, file preview) would go here.
	     }
	         
	      // Method to upload a file to the specified folder
	         private void uploadFileToFolder(String folderName) {
	             JFileChooser fileChooser = new JFileChooser();
	             int option = fileChooser.showOpenDialog(this);
	             if (option == JFileChooser.APPROVE_OPTION) {
	                 File file = fileChooser.getSelectedFile();
	                 if (file != null) {
	                     AzureBlobStorage azureBlobStorage = this.azureBlobStorage;
	                     azureBlobStorage.uploadFile(folderName, file);
	                     JOptionPane.showMessageDialog(this, "File uploaded successfully!");
	                 }
	             }
	             refreshFileExplorer();
	         }
	         
	      // Method to download a folder or file
	        /* private void downloadFolderOrFile(String folderName) {
	             AzureBlobStorage azureBlobStorage = this.azureBlobStorage;
	             azureBlobStorage.downloadFile(folderName);
	             JOptionPane.showMessageDialog(this, "Download started!");
	         }*/
	         
	         private void downloadFolderOrFile(String folderName) {
	        	    JFileChooser directoryChooser = new JFileChooser();
	        	    directoryChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	        	    int option = directoryChooser.showSaveDialog(this);

	        	    if (option == JFileChooser.APPROVE_OPTION) {
	        	        File localDirectory = directoryChooser.getSelectedFile();
	        	        String localDirectoryPath = localDirectory.getAbsolutePath();

	        	        // Download the selected file or folder to the specified local directory
	        	        azureBlobStorage.downloadFileOrFolder(folderName, localDirectoryPath);
	        	        JOptionPane.showMessageDialog(this, "Download completed!");
	        	    }
	        	}

	         
	         // Start browsing in the home directory
	        // navigateTo(new File(System.getProperty("user.home")));
	         
	         
	         
	     
	    
	    
	    
	    

	     /*
	     private void setupMainFrame() {
	         JFrame mainFrame = new JFrame("File Browser with Azure Blob Storage");
	         mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	         mainFrame.setSize(800, 600);
	         mainFrame.setLayout(new BorderLayout());

	         // Ensure getFileTreeComponent() method is available in AzureBlobWindow
	         mainFrame.add(azureBlobWindow.getFileTreeComponent(), BorderLayout.CENTER);

	         mainFrame.setVisible(true);
	     }*/
	 	// -------------------------------------------------------------------------
	     // simple search feature
	     // -------------------------------------------------------------------------
	         /*private String searchFiles(String query){
	             // This should be able to search all the current folder we are at for a specific file
	             // file can be broken down into a few structures:
	             // - name, type, preview text, date created
	             // enter key to perform search

	             // Clear the current file list
	             fileListModel.clear();
	             
	             // Get all files in the current directory
	             //File[] files = currentDirectory.listFiles();
	             int matchCount = 0; // Counter for matching files

	             if (files != null) {
	                 for (File file : files) {
	                     boolean matches = false;

	                     // Check if the file name contains the search query
	                     if (file.getName().toLowerCase().contains(query.toLowerCase())) {
	                         matches = true;
	                     }

	                     // Check if the file type matches
	                     String fileType = getFileType(file); 
	                     if (fileType.toLowerCase().contains(query.toLowerCase())) {
	                         matches = true;
	                     }

	                     // If the file is a text file, we can also check its preview
	                     // if (file.isFile() && file.getName().toLowerCase().endsWith(".txt")) {
	                     //     String previewText = getFilePreviewText(file); // Implement this method to read the first few lines
	                     //     if (previewText.toLowerCase().contains(query.toLowerCase())) {
	                     //         matches = true;
	                     //     }
	                     // }

	                     // If it matches any criteria, add it to the list
	                     if (matches) {
	                         fileListModel.addElement(file);
	                         matchCount++; // Increment match count
	                     }
	                 }
	             }

	             // Return a message based on the search results
	             if (matchCount == 0) {
	                 return "No files found matching \"" + query + "\".";
	             } else {
	                 return matchCount + " file(s) found matching \"" + query + "\".";
	             }
	         }*/
	     /*
	     private void navigateTo(File directory) {
	         if (currentDirectory != null) {
	             navigationStack.pushBack(currentDirectory);
	         }
	         currentDirectory = directory;
	         updateFileList(directory);
	         updateNavigationButtons();
	     }

	     private void updateFileList(File directory) {
	         fileListModel.clear();
	         File[] files = directory.listFiles();
	         if (files != null) {
	             Arrays.sort(files);
	             for (File file : files) {
	                 fileListModel.addElement(file);
	             }
	         }
	         displayFileMetadata(directory);
	    }

	     private void goBack() {
	         File previousDirectory = navigationStack.goBack(currentDirectory);
	         if (previousDirectory != null) {
	             currentDirectory = previousDirectory;
	             updateFileList(previousDirectory);
	        }
	         updateNavigationButtons();
	     }

	     private void goForward() {
	         File nextDirectory = navigationStack.goForward(currentDirectory);
	         if (nextDirectory != null) {
	             currentDirectory = nextDirectory;
	             updateFileList(nextDirectory);
	         }
	         updateNavigationButtons();
	     }*/

	    /* private void updateNavigationButtons() {
	         backButton.setEnabled(navigationStack.canGoBack());
	         forwardButton.setEnabled(navigationStack.canGoForward());
	     }*/
	    
	   

	     // -------------------------------------------------------------------------
	     // Creating a hash map to hold a few file types and their coresponding magic numbers
	     // -------------------------------------------------------------------------
	     private static final Map<String, String> MAGIC_NUMBERS = new HashMap<>();
	     static {
	    	 
	         // some basic photo file types
	         MAGIC_NUMBERS.put("FFD8FF", "JPEG Image");
	         MAGIC_NUMBERS.put("89504E47", "PNG Image");
	         MAGIC_NUMBERS.put("47494638", "GIF Image");
	         MAGIC_NUMBERS.put("25504446", "PDF Document");
	         MAGIC_NUMBERS.put("424D", "BMP Image");
	         MAGIC_NUMBERS.put("49492A00", "TIFF Image (little-endian)");
	         MAGIC_NUMBERS.put("4D4D002A", "TIFF Image (big-endian)");
	   
	          // Audio and Video Types
	         MAGIC_NUMBERS.put("66747970", "MP4"); // MP4/MOV (ftyp)
	         MAGIC_NUMBERS.put("494433", "MP3"); // MP3 (ID3v2)
	         MAGIC_NUMBERS.put("FFFB", "MP3"); // MP3 (MPEG Header)
	         MAGIC_NUMBERS.put("FFF3", "MP3"); // MP3 (MPEG Header)
	         MAGIC_NUMBERS.put("52494646", "WAV"); // WAV/AVI (RIFF)
	         MAGIC_NUMBERS.put("41564920", "AVI"); // AVI
	         MAGIC_NUMBERS.put("664C6143", "FLAC"); // FLAC (fLaC)
	         MAGIC_NUMBERS.put("1A45DFA3", "MKV"); // MKV (EBML)
	         MAGIC_NUMBERS.put("494433", "MP3 Audio");
	         MAGIC_NUMBERS.put("52494646", "WAV Audio");

	         // Basic document types
	         //MAGIC_NUMBERS.put("D0CF11E0A1B11AE1", "DOC");
	         //MAGIC_NUMBERS.put("504B0304", "DOCX"); 
	         MAGIC_NUMBERS.put("D0CF11E0", "Microsoft Office (DOC, XLS, PPT)"); // Compound File Binary Format
	         MAGIC_NUMBERS.put("504B0304", "Microsoft Office/ZIP Archive (DOCX, XLSX, PPTX)"); // ZIP-based formats
	         MAGIC_NUMBERS.put("0x00000000", "Open Document Format (ODT, ODS, ODP)"); // ODF files (general case)
	         MAGIC_NUMBERS.put("7B5C7274", "RTF Document");
	     }
	     /*public static String getFileTypeFromMagicNumber(String hexMagicNumber) {
	         for (Map.Entry<String, String> entry : MAGIC_NUMBERS.entrySet()) {
	             if (hexMagicNumber.startsWith(entry.getKey())) {
	                 return entry.getValue();
	             }
	         }
	         return "Unknown format";
	     }*/ 

	     // -------------------------------------------------------------------------
	     // Creating a method that is able to detect the file type based on it's magic number
	     // -------------------------------------------------------------------------
	    private String getFileType(File file) {
	         // Return "Directory" if the file is actually a directory
	         if (file.isDirectory()) {
	             return "Directory";
	         }
	         //System.out.println("getFileType");
	         // Attempt to read the file's magic number

        	 String blobName = files.get(fileList.getSelectedIndex());
	         
	         //String blobUrl = storageAccountUrl + containerNameFixed + "/" + blobName;
        	 
        	 BlobClientBase blobClient = containerClient.getBlobClient(blobName).getBlockBlobClient();
        	 
	         try (InputStream inputStream = blobClient.openInputStream()) {
	             byte[] bytes = new byte[64]; // Read first 16 bytes for broader magic number matching
	             if (inputStream.read(bytes) != -1) {
	                 StringBuilder hex = new StringBuilder();
	                 for (byte b : bytes) {
	                     hex.append(String.format("%02X", b));
	                 }
	                 
	              //System.out.println("GetFileType "+hex.toString().contains("66747970"));
	                 
	              // Search specifically for the "66747970" (ftyp) signature within the first 64 bytes
	                 if (hex.toString().contains("66747970")) {
	                     return "MP4";
	                 }
	                 if (hex.toString().contains("504B03") || hex.toString().contains("504B05") || hex.toString().contains("504B07")) {
	                	    return "ZIP";
	                	}
	                 
	                 // Check if the file's magic number matches any known file types
	                 for (Map.Entry<String, String> entry : MAGIC_NUMBERS.entrySet()) {
	                	 //System.out.println("Het2Str "+ hex.toString()+" "+entry.getKey());
	                	 
	                     if (hex.toString().startsWith(entry.getKey())) {
	                         return entry.getValue(); // Return the matched file type
	                     }
	                 }
	             }
	         } catch (IOException e) {
	             e.printStackTrace();
	         }

	         return "Unknown Type"; // Return this if no match was found
	     }
	     
	     
	     

	     // -------------------------------------------------------------------------
	     // Display metadata such as name, size, type, and last modified date
	     // -------------------------------------------------------------------------
	     private void displayFileMetadata(File file) {
	         StringBuilder metadata = new StringBuilder();
	         metadata.append("Name: ").append(file.getName()).append("\n");
	         metadata.append("Size: ").append(file.length()).append(" bytes\n");
	         metadata.append("Type: ").append(getFileType(file)).append("\n");
	         metadata.append("Last Modified: ").append(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss")
	                 .format(file.lastModified())).append("\n");
	         fileMetadataArea.setText(metadata.toString());
	     }

	     // -------------------------------------------------------------------------
	     // Display file preview (for text files, show the first few lines)
	     // -------------------------------------------------------------------------
	     
	     /*
	     private void displayFilePreview() {
	    	 
	     }*/
	     
	     private void displayFilePreview(File file) {

	         if (file.isFile() && file.getName().endsWith(".txt")) {
	             try (FileReader fr = new FileReader(file); Scanner scanner = new Scanner(fr)) {
	                 StringBuilder preview = new StringBuilder();
	                 int lineCount = 0;
	                 while (scanner.hasNextLine() && lineCount < 10) {
	                     preview.append(scanner.nextLine()).append("\n");
	                     lineCount++;
	                 }
	                 fileMetadataArea.setText(preview.toString());
	                 
	             } catch (IOException ex) {
	                 fileMetadataArea.setText("Unable to preview file.");
	             }
	         } else {
	             fileMetadataArea.setText("No preview available for this file.");
	         }
	         displayFileMetadata(file);
	     }
	     
	     
	 }